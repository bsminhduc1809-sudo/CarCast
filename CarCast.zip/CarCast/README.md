# CarCast — xem YouTube, web, video và chiếu màn hình điện thoại trên Android Auto

Ứng dụng viết mới hoàn toàn (Kotlin), lấy cảm hứng từ chức năng của AAcast Pro nhưng
**chỉ dùng thư viện chính thức của Google (Car App Library)**, không đăng nhập, không thu phí,
không gửi dữ liệu đi đâu.

## Chức năng

| Trên màn hình xe | Cách hoạt động |
|---|---|
| Màn hình chính: đồng hồ, ngày, 4 ô YouTube / Web / Video / Chiếu ĐT | Vẽ bằng giao diện Android lên VirtualDisplay nối với Surface của xe |
| YouTube & trình duyệt web | WebView; chạm để bấm, nút ✋ (PAN) rồi kéo để cuộn; nút **Tìm** mở bàn phím xe |
| Video trong máy | ExoPlayer (Media3); chọn file trên điện thoại; nút tua ±10 s |
| Chiếu màn hình điện thoại | MediaProjection → Surface của xe; chạm trên xe được chuyển thành chạm trên điện thoại qua Trợ năng |
| **Chia 2–3 khung** | Nhiều WebView song song trên một màn hình ảo; chạm chọn khung (viền xanh) → khung đó phát tiếng và nhận cuộn/bàn phím |
| **Tắt màn hình điện thoại vẫn dùng** | Nội dung của app vẽ trên màn hình ảo, không phụ thuộc màn hình điện thoại; PARTIAL_WAKE_LOCK giữ CPU chạy |
| Khóa an toàn | Đọc tốc độ xe từ Android Auto (dự phòng GPS); > 5 km/h trong 3 s thì tạm dừng & che nội dung |

## Hai tính năng vừa thêm

### Chia 2–3 khung
- Mở từ ô **"2 khung"** trên màn hình chính, hoặc **Menu › Chia 2/3 khung** trên xe, hoặc nút trong app điện thoại.
- Mỗi khung là một trang web riêng (ví dụ YouTube + Google Maps). Chạm vào khung để **chọn** — khung đang chọn có viền xanh, **chỉ khung đó phát tiếng**, và nhận thao tác cuộn (nút ✋) cùng bàn phím.
- Mỗi khung có thanh nhỏ: `⌂` về trang YouTube, `↻` tải lại.

### Tắt màn hình điện thoại vẫn chạm được trên xe
- **Với web / video / chia khung của CarCast:** bật công tắc *"Giữ hoạt động khi tắt màn hình"* (mục 5 trong app) rồi bấm nút nguồn — màn hình xe vẫn hiện và chạm bình thường, vì nội dung được vẽ riêng cho màn hình xe, không phải màn hình điện thoại.
- **Với chiếu nguyên màn hình điện thoại:** không thể tắt hẳn màn hình, vì chiếu là sao chép đúng những gì điện thoại đang hiển thị (tắt màn thì xe cũng thấy đen). Chỉ hạ được độ sáng xuống thấp nhất; màn vẫn bật. Nếu muốn tắt màn hình thật sự thì dùng chế độ web/video/chia khung của CarCast thay cho chiếu.

## Cập nhật mới nhất

- **Chỉ dẫn dẫn đường + HUD tốc độ**: CarCast đọc **thông báo điều hướng** của Google Maps/VietMap (khi các app đó đang dẫn đường) và hiện thanh **mũi tên + chỉ dẫn** ở trên màn hình xe, kèm **HUD tốc độ** (GPS) ở góc dưới. Hai overlay này hiển thị trên mọi chế độ (kể cả khi đang chiếu/khóa tốc độ). Cấp quyền một lần ở app điện thoại (mục 5 → "Cấp quyền đọc thông báo"), bật/tắt bằng công tắc. *Chỉ dẫn do Google Maps/VietMap tạo ra — bác vẫn chạy dẫn đường trên các app đó; CarCast chỉ hiển thị lại gọn.*


- **Xem trước & thiết kế bố cục trên điện thoại** (mục 3 trong app → nút "Xem trước & thiết kế bố cục"): canvas đúng tỷ lệ màn ô tô (chọn 16:9, 5:3, 20:9…), render layout thật bằng WebView để thử bố cục mà không cần lên xe. Đổi kiểu (Màn chính / 2–3 khung / Bản đồ / Video / Web), sửa nội dung từng khung (web hoặc video), **lưu thành bố cục mẫu**, nạp lại để sửa, hoặc mở thẳng lên xe.


- **Full màn hình**: nội dung tràn viền, không còn bị co nhỏ khi thanh nút của Android Auto hiện ra (chỉ các thanh điều khiển được chừa lề).
- **Bản đồ trong app**: ô **"Bản đồ"** ở màn hình chính vẽ bản đồ OpenStreetMap theo GPS (tự vẽ, không phải Google Maps). **Menu › Dẫn đường** giao điểm đến cho Google Maps/VietMap gốc chạy trên khung Android Auto của chúng. Muốn xem **VietMap** đầy đủ trên xe: chạy VietMap trên điện thoại rồi **Chiếu màn hình**. *(Không app nào nhúng được bản đồ Google Maps thật vào màn hình của mình — Maps tự vẽ qua khung riêng.)*
- **Tìm bằng bàn phím xe**: nút **"Tìm"** ở thanh trên + **Menu › Tìm trên YouTube** (chỉ khi xe đỗ). Android Auto không mở micro cho app ngoài nên không có tìm bằng giọng nói.
- **Chiếu đúng tỷ lệ màn xe**: công tắc **"Lấp đầy màn hình xe"** (mục 4 trong app điện thoại). Tắt = giữ tỷ lệ điện thoại (có viền đen); Bật = phủ kín màn xe, cắt bớt mép trên/dưới của điện thoại.

## Build ra file APK

### Cách 1 – GitHub (không cần cài gì)
1. Tạo repository mới trên github.com (để Private).
2. Tải toàn bộ thư mục này lên (Add file → Upload files, kéo thả cả thư mục, gồm cả `.github`).
3. Vào tab **Actions** → workflow *Build APK* tự chạy (~5 phút).
4. Mở lần chạy đã xong → mục **Artifacts** → tải `CarCast-apk` → giải nén ra `app-release.apk`.

### Cách 2 – Android Studio
Mở thư mục `CarCast` bằng Android Studio (bản Koala trở lên) → *Build › Build APK(s)*.

## Cài đặt & bật trên xe
1. Cài `app-release.apk` vào điện thoại (cho phép cài từ nguồn không xác định).
2. Mở CarCast trên điện thoại → **Cấp quyền**, **Bật Trợ năng** (nếu muốn chạm khi chiếu màn hình).
3. Android Auto → chạm 10 lần vào "Phiên bản" để bật chế độ nhà phát triển → menu ⋮ →
   *Cài đặt dành cho nhà phát triển* → bật **Nguồn không xác định (Unknown sources)**.
4. Android Auto → *Tùy chỉnh trình chạy* → bật CarCast.
5. Kết nối xe → mở CarCast trên màn hình xe.

## Giới hạn cần biết
- Bàn phím trên xe chỉ dùng được khi xe đứng yên (quy định của Android Auto) — có thể nhập địa chỉ từ điện thoại.
- Khi chiếu màn hình, mỗi phiên cần bấm xác nhận trên điện thoại (bắt buộc của Android).
  Xoay ngang điện thoại để hình chiếu lấp đầy màn hình xe.
- Cuộn trang: bấm nút ✋ (PAN) trước rồi kéo; một số đầu xe chỉ hỗ trợ chạm (không kéo).
- Android Auto các bản mới có thể thay đổi cách xử lý ứng dụng cài ngoài; nếu không thấy biểu tượng,
  kiểm tra lại mục "Nguồn không xác định".

## Cấu trúc mã nguồn
```
app/src/main/java/com/duc/carcast/
├── CarHub.kt                 # trạng thái chung, điều phối chế độ
├── Prefs.kt                  # cài đặt
├── car/
│   ├── CarCastService.kt     # điểm vào Android Auto (CarAppService + Session)
│   ├── Screens.kt            # NavigationTemplate, Menu, bàn phím tìm kiếm
│   ├── CarRenderer.kt        # nhận Surface của xe, VirtualDisplay, chuyển tiếp cảm ứng
│   ├── CarPresentation.kt    # giao diện trên xe: launcher, WebView, ExoPlayer, lớp khóa
│   └── SpeedGuard.kt         # khóa an toàn theo tốc độ
├── mirror/
│   ├── MirrorController.kt   # MediaProjection → màn hình xe, quy đổi toạ độ chạm
│   ├── MirrorService.kt      # dịch vụ nền khi chiếu
│   └── TouchAccessibilityService.kt  # chạm hộ trên điện thoại
└── phone/MainActivity.kt     # ứng dụng trên điện thoại
```
