package com.duc.carcast.phone

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import com.duc.carcast.CarHub
import com.duc.carcast.Prefs
import com.duc.carcast.WakeKeeper
import com.duc.carcast.mirror.MirrorController
import com.duc.carcast.mirror.MirrorService
import com.duc.carcast.mirror.TouchAccessibilityService

/** Ứng dụng trên điện thoại: cấp quyền, cài đặt, chọn video, bật chiếu màn hình. */
class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var mirrorBtn: Button
    private lateinit var accBtn: Button

    private fun dp(v: Int) = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i != null && i.getBooleanExtra(EXTRA_REQUEST_MIRROR, false)) {
            i.removeExtra(EXTRA_REQUEST_MIRROR)
            CarHub.cancelMirrorRequestNotification(this)
            requestMirror()
        }
    }

    override fun onResume() {
        super.onResume()
        CarHub.onStateChanged = { refresh() }
        refresh()
    }

    override fun onPause() {
        CarHub.onStateChanged = null
        super.onPause()
    }

    // ---------------- Giao diện ----------------

    private fun buildUi() {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(32))
        }
        col.addView(TextView(this).apply {
            text = "CarCast"
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
        })
        col.addView(TextView(this).apply {
            text = "Xem YouTube, web, video và chiếu màn hình điện thoại lên Android Auto"
            textSize = 15f
            alpha = 0.75f
        })

        status = TextView(this).apply {
            textSize = 15f
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(0x2290A4AE)
            }
        }
        col.addView(status, lp(top = 16))

        section(col, "1. Cấp quyền")
        col.addView(button("Cấp quyền thông báo, vị trí, tốc độ xe") { requestPerms() })
        accBtn = button("Bật Trợ năng (chạm điều khiển khi chiếu)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        col.addView(accBtn)

        section(col, "2. Nội dung phát trên xe")
        col.addView(button("Chọn video trong máy…") { pickVideo() })
        val url = EditText(this).apply {
            hint = "Địa chỉ web hoặc từ khoá YouTube"
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine()
        }
        col.addView(url, lp(top = 8))
        col.addView(button("Mở trên màn hình xe") {
            if (!CarHub.isCarConnected) toast("Chưa kết nối Android Auto")
            else CarHub.submitText(url.text.toString())
        })
        val home = EditText(this).apply {
            setText(Prefs.homeUrl(this@MainActivity))
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine()
        }
        col.addView(label("Trang mở khi bấm ô YouTube:"))
        col.addView(home)
        col.addView(button("Lưu trang YouTube") {
            Prefs.setHomeUrl(this, home.text.toString().trim().ifEmpty { "https://m.youtube.com" })
            toast("Đã lưu")
        })

        section(col, "3. Chia 2–3 khung cùng lúc")
        col.addView(label("Hai hoặc ba trang web song song trên màn hình xe (ví dụ YouTube + Google Maps). Chạm vào một khung để chọn — khung được chọn có viền xanh, phát tiếng và nhận thao tác cuộn/bàn phím."))
        val splitRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        splitRow.addView(button("Mở 2 khung") { openSplit(2) }, rowLp())
        splitRow.addView(button("Mở 3 khung") { openSplit(3) }, rowLp())
        col.addView(splitRow, lp(top = 4))

        section(col, "4. Chiếu màn hình điện thoại")
        col.addView(label("Xoay ngang điện thoại để hình chiếu lấp đầy màn hình xe. Bật Trợ năng ở mục 1 để chạm trên xe điều khiển được điện thoại."))
        mirrorBtn = button("Bắt đầu chiếu") {
            if (MirrorController.isActive) MirrorController.stop() else requestMirror()
        }
        col.addView(mirrorBtn)

        section(col, "5. Tắt màn hình điện thoại khi dùng")
        val awake = Switch(this).apply {
            text = "Giữ hoạt động khi điện thoại tắt màn hình"
            isChecked = Prefs.keepAwake(this@MainActivity)
            setOnCheckedChangeListener { _, checked ->
                Prefs.setKeepAwake(this@MainActivity, checked)
                WakeKeeper.update(this@MainActivity)
            }
        }
        col.addView(awake, lp(top = 4))
        col.addView(label(SCREEN_OFF_NOTE))

        section(col, "6. An toàn")
        val sw = Switch(this).apply {
            text = "Tự tạm dừng video/web/chiếu khi xe đang chạy"
            isChecked = Prefs.speedLock(this@MainActivity)
            setOnCheckedChangeListener { _, checked ->
                Prefs.setSpeedLock(this@MainActivity, checked)
                if (!checked) toast("Chỉ nên tắt khi người xem là hành khách và màn hình không nằm trong tầm mắt tài xế")
            }
        }
        col.addView(sw, lp(top = 4))
        val limit = EditText(this).apply {
            setText(Prefs.speedLimit(this@MainActivity).toString())
            inputType = InputType.TYPE_CLASS_NUMBER
            setSingleLine()
        }
        col.addView(label("Ngưỡng tốc độ khóa (km/h):"))
        col.addView(limit)
        col.addView(button("Lưu ngưỡng") {
            Prefs.setSpeedLimit(this, limit.text.toString().toIntOrNull() ?: 5)
            limit.setText(Prefs.speedLimit(this).toString())
            toast("Đã lưu – áp dụng từ lần kết nối xe tiếp theo")
        })

        section(col, "Hướng dẫn bật trên Android Auto")
        col.addView(label(SETUP_GUIDE))

        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun lp(top: Int = 8) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(top) }

    private fun rowLp() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        .apply { topMargin = dp(8); marginStart = dp(4); marginEnd = dp(4) }

    private fun section(col: LinearLayout, title: String) {
        col.addView(TextView(this).apply {
            text = title
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
        }, lp(top = 24))
    }

    private fun label(t: String) = TextView(this).apply {
        text = t
        textSize = 14f
        setPadding(0, dp(6), 0, 0)
    }

    private fun button(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setOnClickListener { onClick() }
        layoutParams = lp()
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    private fun refresh() {
        if (!::status.isInitialized) return
        val acc = TouchAccessibilityService.isEnabled(this)
        val lines = listOf(
            (if (CarHub.isCarConnected) "🟢 Đã kết nối Android Auto" else "⚪ Chưa kết nối Android Auto"),
            (if (MirrorController.isActive) "🟢 Đang chiếu màn hình" else "⚪ Không chiếu màn hình"),
            (if (acc) "🟢 Trợ năng đã bật" else "🟠 Trợ năng chưa bật (không chạm được khi chiếu)"),
            (if (CarHub.blocked) "🔒 Xe đang chạy – nội dung tạm khóa" else "")
        ).filter { it.isNotEmpty() }
        status.text = lines.joinToString("\n")
        mirrorBtn.text = if (MirrorController.isActive) "Dừng chiếu" else "Bắt đầu chiếu"
        accBtn.visibility = if (acc) View.GONE else View.VISIBLE
        status.setTextColor(if (isNight()) Color.WHITE else Color.BLACK)
    }

    private fun isNight(): Boolean =
        (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES

    // ---------------- Hành động ----------------

    private fun openSplit(count: Int) {
        if (!CarHub.isCarConnected) {
            toast("Chưa kết nối Android Auto – mở sẵn, sẽ hiện khi kết nối")
        }
        CarHub.openSplit(this, count)
    }

    private fun requestPerms() {
        val perms = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            "com.google.android.gms.permission.CAR_SPEED",
        )
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        requestPermissions(perms.toTypedArray(), REQ_PERMS)
    }

    private fun pickVideo() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("video/*")
        startActivityForResult(i, REQ_VIDEO)
    }

    private fun requestMirror() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_MIRROR)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_MIRROR -> {
                if (resultCode == RESULT_OK && data != null) {
                    MirrorService.start(this, resultCode, data)
                    if (!CarHub.isCarConnected) toast("Đã bật chiếu – sẽ hiện khi kết nối Android Auto")
                } else {
                    toast("Đã huỷ chiếu màn hình")
                }
            }
            REQ_VIDEO -> {
                val uri: Uri = data?.data ?: return
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: SecurityException) {
                }
                Prefs.setLastVideo(this, uri.toString())
                if (CarHub.isCarConnected) {
                    CarHub.openVideo(this, uri)
                    toast("Đang phát trên màn hình xe")
                } else {
                    CarHub.videoUri = uri
                    CarHub.videoPositionMs = 0L
                    toast("Đã chọn – mở ô Video trên xe để phát")
                }
            }
        }
        refresh()
    }

    companion object {
        const val EXTRA_REQUEST_MIRROR = "request_mirror"
        private const val REQ_PERMS = 1
        private const val REQ_VIDEO = 2
        private const val REQ_MIRROR = 3

        private val SCREEN_OFF_NOTE = """
            • Với các chế độ của CarCast (web, video, chia khung): bật công tắc trên rồi bấm nút nguồn tắt màn hình điện thoại — màn hình xe vẫn hiển thị và chạm bình thường, vì nội dung được vẽ riêng cho màn hình xe.
            • Với chế độ "Chiếu màn hình điện thoại": không thể tắt hẳn màn hình vì chiếu là sao chép đúng màn hình đang hiện. Chỉ nên hạ độ sáng điện thoại xuống mức thấp nhất; màn vẫn bật nhưng mờ.
        """.trimIndent()

        private val SETUP_GUIDE = """
            Android Auto chỉ hiện ứng dụng cài ngoài CH Play khi bật "Nguồn không xác định":
            1) Mở Android Auto trên điện thoại (Cài đặt > Thiết bị đã kết nối > Android Auto).
            2) Kéo xuống cuối, chạm 10 lần vào dòng "Phiên bản" → xác nhận để bật Chế độ nhà phát triển.
            3) Menu ⋮ (góc trên phải) > Cài đặt dành cho nhà phát triển → bật "Nguồn không xác định" (Unknown sources).
            4) Quay lại Android Auto > Tùy chỉnh trình chạy (Customize launcher) → bật CarCast.
            5) Kết nối xe, mở biểu tượng CarCast trên màn hình xe.

            Mẹo: Nút ✋ (PAN) trên xe bật chế độ kéo để cuộn trang web; nút Tìm mở bàn phím (chỉ khi xe đứng yên). Trong chế độ chia khung, bàn phím nạp địa chỉ vào khung đang chọn.
        """.trimIndent()
    }
}
