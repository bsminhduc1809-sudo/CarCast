package com.duc.carcast.nav

import android.app.Notification
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.duc.carcast.CarHub

/**
 * Đọc thông báo điều hướng của Google Maps/VietMap (khi các app đó đang dẫn
 * đường) và chuyển chỉ dẫn vào NavController để hiển thị lên màn hình xe.
 * Không đọc nội dung thông báo của app khác.
 */
class NavNotificationListener : NotificationListenerService() {

    private val main = Handler(Looper.getMainLooper())

    override fun onListenerConnected() {
        // Bắt lại chỉ dẫn đang hiển thị (nếu đã dẫn đường từ trước).
        try {
            activeNotifications?.forEach { handle(it) }
        } catch (_: Throwable) {
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn != null) handle(sbn)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        val pkg = sbn?.packageName ?: return
        if (sourceOf(pkg) != null) main.post { NavController.clear() }
    }

    private fun handle(sbn: StatusBarNotification) {
        val src = sourceOf(sbn.packageName) ?: return
        val n = sbn.notification ?: return
        val ongoing = (n.flags and Notification.FLAG_ONGOING_EVENT) != 0
        val isNavCat = n.category == Notification.CATEGORY_NAVIGATION
        if (!ongoing && !isNavCat) return

        val ex = n.extras ?: return
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty().trim()
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty().trim()
        val sub = ex.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString().orEmpty().trim()
        if (title.isEmpty() && text.isEmpty()) return

        val icon = try {
            n.getLargeIcon()?.loadDrawable(this)
        } catch (_: Throwable) {
            null
        }
        main.post { NavController.set(title, text, sub, icon, src) }
        CarHub.notifyChanged()
    }

    private fun sourceOf(pkg: String?): String? = when {
        pkg == null -> null
        pkg == "com.google.android.apps.maps" -> "Google Maps"
        pkg.contains("vietmap", ignoreCase = true) -> "VietMap"
        else -> null
    }
}
