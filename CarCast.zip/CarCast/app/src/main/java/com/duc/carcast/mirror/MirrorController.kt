package com.duc.carcast.mirror

import android.content.Context
import android.graphics.Point
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Display
import android.view.Surface
import com.duc.carcast.CarHub

/**
 * Quản lý phiên chiếu màn hình điện thoại (MediaProjection).
 * Hình chiếu được ghi vào một Surface do CarPresentation cung cấp (bề mặt của
 * TextureView), ở ĐÚNG độ phân giải điện thoại để không bị thêm viền đen; việc
 * co giãn "vừa khung" hay "lấp đầy" do TextureView xử lý bằng ma trận biến đổi.
 */
object MirrorController {
    private const val TAG = "MirrorController"

    private var appContext: Context? = null
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null

    val isActive: Boolean get() = projection != null

    private val callback = object : MediaProjection.Callback() {
        override fun onStop() = onProjectionStopped()
    }

    fun start(ctx: Context, p: MediaProjection) {
        stop()
        appContext = ctx.applicationContext
        projection = p
        p.registerCallback(callback, Handler(Looper.getMainLooper()))
        CarHub.mode = CarHub.Mode.MIRROR
        CarHub.renderer?.refreshMirror()
        CarHub.notifyChanged()
    }

    /** Lấy kích thước thật của màn hình điện thoại (để đặt kích thước ảnh chiếu). */
    fun phoneSize(): Point? {
        val ctx = appContext ?: return null
        return try {
            val dm = ctx.getSystemService(DisplayManager::class.java)
            val d = dm.getDisplay(Display.DEFAULT_DISPLAY) ?: return null
            val p = Point()
            @Suppress("DEPRECATION")
            d.getRealSize(p)
            if (p.x > 0 && p.y > 0) p else null
        } catch (_: Throwable) {
            null
        }
    }

    fun phoneDpi(): Int {
        val ctx = appContext ?: return 320
        return ctx.resources.displayMetrics.densityDpi
    }

    /** Gắn ảnh chiếu vào Surface của TextureView (kích thước = độ phân giải điện thoại). */
    fun attachSurface(surface: Surface, phoneW: Int, phoneH: Int, dpi: Int): Boolean {
        val p = projection ?: return false
        return try {
            val vd = display
            if (vd == null) {
                display = p.createVirtualDisplay(
                    "CarCastMirror", phoneW, phoneH, dpi,
                    0, surface, null, null
                )
            } else {
                vd.resize(phoneW, phoneH, dpi)
                vd.surface = surface
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Không tạo được màn hình chiếu", e)
            false
        }
    }

    fun detachSurface() {
        display?.surface = null
    }

    fun stop() {
        val p = projection ?: return
        try {
            p.stop()
        } catch (_: Exception) {
            onProjectionStopped()
        }
    }

    private fun onProjectionStopped() {
        val p = projection ?: return
        projection = null
        try {
            p.unregisterCallback(callback)
        } catch (_: Exception) {
        }
        display?.release()
        display = null
        if (CarHub.mode == CarHub.Mode.MIRROR) CarHub.mode = CarHub.Mode.HOME
        CarHub.renderer?.refreshMirror()
        appContext?.let { MirrorService.stop(it) }
        CarHub.notifyChanged()
    }

    // ---------- Chạm hộ trên điện thoại (toạ độ đã ở hệ điện thoại) ----------

    fun tap(px: Float, py: Float) {
        val svc = TouchAccessibilityService.instance
        if (svc == null) {
            CarHub.presentation?.toast("Bật Trợ năng CarCast trên điện thoại để điều khiển cảm ứng")
            return
        }
        svc.tap(px, py)
    }

    fun swipe(px1: Float, py1: Float, px2: Float, py2: Float) {
        TouchAccessibilityService.instance?.swipe(px1, py1, px2, py2)
    }

    fun globalBack() {
        TouchAccessibilityService.instance?.back()
    }
}
