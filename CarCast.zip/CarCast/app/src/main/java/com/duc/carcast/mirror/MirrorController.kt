package com.duc.carcast.mirror

import android.content.Context
import android.graphics.Point
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Display
import android.view.Surface
import com.duc.carcast.CarHub

/**
 * Quản lý phiên chiếu màn hình điện thoại (MediaProjection) lên bề mặt xe.
 * Android 14+: mỗi lần cho phép chỉ tạo được MỘT VirtualDisplay, nên khi bề mặt xe
 * thay đổi ta chỉ đổi Surface/kích thước của VirtualDisplay hiện có.
 */
object MirrorController {
    private const val TAG = "MirrorController"

    private var appContext: Context? = null
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var carW = 0
    private var carH = 0

    val isActive: Boolean get() = projection != null

    private val callback = object : MediaProjection.Callback() {
        override fun onStop() = onProjectionStopped()
    }

    fun start(ctx: Context, p: MediaProjection) {
        stop()
        appContext = ctx.applicationContext
        projection = p
        p.registerCallback(callback, Handler(Looper.getMainLooper()))
        CarHub.mode = CarHub.Mode.MIRROR
        CarHub.renderer?.refreshMirror()
        CarHub.notifyChanged()
    }

    /** Gắn hình chiếu vào Surface của xe. */
    fun attach(ctx: Context, surface: Surface, w: Int, h: Int, dpi: Int): Boolean {
        val p = projection ?: return false
        carW = w
        carH = h
        val existing = display
        return try {
            if (existing == null) {
                display = p.createVirtualDisplay(
                    "CarCastMirror", w, h, dpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    surface, null, null
                )
            } else {
                existing.resize(w, h, dpi)
                existing.surface = surface
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Không tạo được màn hình chiếu", e)
            false
        }
    }

    fun detach() {
        display?.surface = null
    }

    fun stop() {
        val p = projection ?: return
        try {
            p.stop() // sẽ gọi onProjectionStopped()
        } catch (_: Exception) {
            onProjectionStopped()
        }
    }

    private fun onProjectionStopped() {
        val p = projection ?: return
        projection = null
        try {
            p.unregisterCallback(callback)
        } catch (_: Exception) {
        }
        display?.release()
        display = null
        if (CarHub.mode == CarHub.Mode.MIRROR) CarHub.mode = CarHub.Mode.HOME
        CarHub.renderer?.refreshMirror()
        CarHub.presentation?.showHome()
        appContext?.let { MirrorService.stop(it) }
        CarHub.notifyChanged()
    }

    // ---------- Chuyển toạ độ chạm trên xe → toạ độ trên điện thoại ----------

    private fun phoneSize(): Point? {
        val ctx = appContext ?: return null
        val d = ctx.getSystemService(DisplayManager::class.java)?.getDisplay(Display.DEFAULT_DISPLAY)
            ?: return null
        val p = Point()
        @Suppress("DEPRECATION")
        d.getRealSize(p)
        return p
    }

    /** Hình điện thoại được thu nhỏ vừa khung xe và căn giữa (có viền đen). */
    private fun map(x: Float, y: Float): Pair<Float, Float>? {
        val ph = phoneSize() ?: return null
        if (carW == 0 || carH == 0) return null
        val scale = minOf(carW.toFloat() / ph.x, carH.toFloat() / ph.y)
        val offX = (carW - ph.x * scale) / 2f
        val offY = (carH - ph.y * scale) / 2f
        val px = (x - offX) / scale
        val py = (y - offY) / scale
        if (px < 0 || py < 0 || px > ph.x || py > ph.y) return null
        return px to py
    }

    fun tap(x: Float, y: Float) {
        val svc = TouchAccessibilityService.instance
        if (svc == null) {
            CarHub.presentation?.toast("Bật Trợ năng CarCast trên điện thoại để điều khiển cảm ứng")
            return
        }
        val (px, py) = map(x, y) ?: return
        svc.tap(px, py)
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float) {
        val svc = TouchAccessibilityService.instance ?: return
        val ph = phoneSize() ?: return
        val a = map(x1, y1) ?: return
        val scale = minOf(carW.toFloat() / ph.x, carH.toFloat() / ph.y)
        val bx = (a.first + (x2 - x1) / scale).coerceIn(0f, ph.x - 1f)
        val by = (a.second + (y2 - y1) / scale).coerceIn(0f, ph.y - 1f)
        svc.swipe(a.first, a.second, bx, by)
    }

    fun globalBack() {
        TouchAccessibilityService.instance?.back()
    }
}
