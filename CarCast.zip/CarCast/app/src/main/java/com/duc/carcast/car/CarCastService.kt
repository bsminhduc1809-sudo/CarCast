package com.duc.carcast.car

import android.content.Intent
import androidx.car.app.CarAppService
import androidx.car.app.Screen
import androidx.car.app.Session
import androidx.car.app.validation.HostValidator
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.duc.carcast.CarHub
import com.duc.carcast.WakeKeeper

/** Điểm vào Android Auto (Car App Library, loại NAVIGATION để được vẽ lên màn hình xe). */
class CarCastService : CarAppService() {

    // Ứng dụng cài ngoài (sideload) để dùng cá nhân → chấp nhận mọi host.
    override fun createHostValidator(): HostValidator = HostValidator.ALLOW_ALL_HOSTS_VALIDATOR

    override fun onCreateSession(): Session = CarCastSession()
}

class CarCastSession : Session() {

    override fun onCreateScreen(intent: Intent): Screen {
        val renderer = CarRenderer(carContext)
        val guard = SpeedGuard(carContext) { moving -> CarHub.setBlocked(moving) }

        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onCreate(owner: LifecycleOwner) {
                CarHub.renderer = renderer
                renderer.register()
                guard.start()
                WakeKeeper.update(carContext)
                CarHub.notifyChanged()
            }

            override fun onDestroy(owner: LifecycleOwner) {
                guard.stop()
                CarHub.setBlocked(false)
                renderer.unregister()
                if (CarHub.renderer === renderer) CarHub.renderer = null
                WakeKeeper.release()
                CarHub.notifyChanged()
            }
        })
        return HomeScreen(carContext)
    }
}
