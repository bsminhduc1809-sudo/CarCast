package com.duc.carcast.phone

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import com.duc.carcast.CarHub
import com.duc.carcast.Prefs
import com.duc.carcast.PresetStore
import com.duc.carcast.SplitPreset

/**
 * Xem trước và thiết kế bố cục màn hình xe ngay trên điện thoại.
 * Vẽ canvas đúng tỷ lệ màn ô tô và render layout thật (WebView thật) để
 * kiểm tra bố cục, chỉnh nội dung từng khung, lưu thành "bố cục mẫu".
 */
class PreviewActivity : Activity() {

    private enum class Layout { HOME, SPLIT2, SPLIT3, MAP, VIDEO, WEB }

    private var layout = Layout.SPLIT2
    private var aspectW = 16
    private var aspectH = 9
    private var activeFrame = 0
    // Nội dung tối đa 3 khung: URL web, hoặc CarHub.VIDEO_SENTINEL.
    private val specs = arrayListOf("https://m.youtube.com", "https://www.google.com/maps", "https://www.google.com")

    private lateinit var canvas: FrameLayout
    private lateinit var frameEditor: LinearLayout
    private lateinit var urlEdit: EditText
    private lateinit var nameEdit: EditText
    private lateinit var presetBox: LinearLayout
    private lateinit var layoutRow: LinearLayout
    private lateinit var aspectRow: LinearLayout
    private lateinit var frameBtnRow: LinearLayout
    private val liveWebViews = ArrayList<WebView>()
    private val frameViews = ArrayList<View>()

    private fun dp(v: Int) = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    private fun count() = when (layout) {
        Layout.SPLIT3 -> 3; Layout.SPLIT2 -> 2; else -> 1
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Xem trước bố cục"
        buildUi()
        render()
        rebuildPresets()
    }

    override fun onDestroy() {
        destroyWebViews()
        super.onDestroy()
    }

    // ---------------- Giao diện điều khiển ----------------

    private fun buildUi() {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(28))
        }

        col.addView(TextView(this).apply {
            text = "Xem trước bố cục màn hình xe"
            textSize = 20f; typeface = Typeface.DEFAULT_BOLD
        })
        col.addView(note("Canvas dưới đây đúng tỷ lệ màn ô tô, dùng WebView thật để bác thử bố cục trước khi lên xe."))

        canvas = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
        }
        col.addView(canvas, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(200)
        ).apply { topMargin = dp(10) })

        col.addView(sub("Kiểu bố cục"))
        layoutRow = chipRow(
            "Màn chính" to { setLayout(Layout.HOME) },
            "2 khung" to { setLayout(Layout.SPLIT2) },
            "3 khung" to { setLayout(Layout.SPLIT3) },
            "Bản đồ" to { setLayout(Layout.MAP) },
            "Video" to { setLayout(Layout.VIDEO) },
            "Web" to { setLayout(Layout.WEB) },
        )
        col.addView(layoutRow)

        col.addView(sub("Tỷ lệ màn xe"))
        aspectRow = chipRow(
            "16:9" to { setAspect(16, 9) },
            "16:10" to { setAspect(16, 10) },
            "5:3" to { setAspect(5, 3) },
            "20:9" to { setAspect(20, 9) },
            "24:9" to { setAspect(24, 9) },
            "4:3" to { setAspect(4, 3) },
        )
        col.addView(aspectRow)

        // Trình sửa nội dung khung (hiện khi split/web)
        frameEditor = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(frameEditor)
        frameEditor.addView(sub("Nội dung khung"))
        frameBtnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        frameEditor.addView(frameBtnRow)
        urlEdit = EditText(this).apply {
            hint = "Địa chỉ web của khung đang chọn"
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine()
        }
        frameEditor.addView(urlEdit)
        val applyRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        applyRow.addView(btn("Đặt web") {
            specs[activeFrame] = normalizeUrl(urlEdit.text.toString()); render()
        }, rowLp())
        applyRow.addView(btn("Khung video") {
            specs[activeFrame] = CarHub.VIDEO_SENTINEL; render()
        }, rowLp())
        applyRow.addView(btn("YouTube") {
            specs[activeFrame] = Prefs.homeUrl(this); urlEdit.setText(specs[activeFrame]); render()
        }, rowLp())
        frameEditor.addView(applyRow, lp())

        col.addView(sub("Lưu bố cục mẫu"))
        nameEdit = EditText(this).apply { hint = "Tên bố cục (vd: YouTube + Maps)"; setSingleLine() }
        col.addView(nameEdit)
        val saveRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        saveRow.addView(btn("Lưu bố cục mẫu") { savePreset() }, rowLp())
        saveRow.addView(btn("Mở ngay trên xe") { openOnCar() }, rowLp())
        col.addView(saveRow, lp())

        col.addView(sub("Bố cục mẫu đã lưu"))
        presetBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(presetBox)

        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun lp() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(8) }

    private fun rowLp() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        .apply { marginStart = dp(4); marginEnd = dp(4); topMargin = dp(8) }

    private fun sub(t: String) = TextView(this).apply {
        text = t; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(16), 0, dp(2))
    }

    private fun note(t: String) = TextView(this).apply { text = t; textSize = 13f; alpha = 0.7f; setPadding(0, dp(4), 0, 0) }

    private fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setOnClickListener { onClick() }
    }

    private fun chipRow(vararg items: Pair<String, () -> Unit>): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        items.forEach { (label, action) ->
            row.addView(Button(this).apply {
                text = label; isAllCaps = false; setOnClickListener { action() }
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { marginEnd = dp(6) })
        }
        return HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }
            .let { hsv -> LinearLayout(this).apply { addView(hsv, lp()) } }
    }

    // ---------------- Trạng thái ----------------

    private fun setLayout(l: Layout) {
        layout = l
        if (activeFrame >= count()) activeFrame = 0
        render()
    }

    private fun setAspect(w: Int, h: Int) {
        aspectW = w; aspectH = h; render()
    }

    private fun selectFrame(i: Int) {
        activeFrame = i
        urlEdit.setText(if (specs[i] == CarHub.VIDEO_SENTINEL) "" else specs[i])
        updateFrameBorders()
        updateFrameButtons()
    }

    private fun normalizeUrl(t: String): String {
        val s = t.trim()
        if (s.isEmpty()) return "https://www.google.com"
        return if (s.startsWith("http://") || s.startsWith("https://")) s else "https://$s"
    }

    // ---------------- Vẽ canvas ----------------

    private fun destroyWebViews() {
        liveWebViews.forEach { it.stopLoading(); it.destroy() }
        liveWebViews.clear()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun makeWeb(url: String): WebView = WebView(this).also { wv ->
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.useWideViewPort = true
        wv.settings.loadWithOverviewMode = true
        wv.loadUrl(url)
        liveWebViews.add(wv)
    }

    private fun render() {
        destroyWebViews()
        frameViews.clear()
        canvas.removeAllViews()

        // Đặt chiều cao canvas đúng tỷ lệ màn xe theo bề rộng hiện có.
        val width = resources.displayMetrics.widthPixels - dp(32)
        canvas.layoutParams = (canvas.layoutParams as LinearLayout.LayoutParams).apply {
            this.width = ViewGroup.LayoutParams.MATCH_PARENT
            height = (width.toFloat() / aspectW * aspectH).toInt().coerceIn(dp(120), dp(520))
        }

        val content: View = when (layout) {
            Layout.HOME -> buildHomePreview()
            Layout.MAP -> makeWeb("file:///android_asset/map.html")
            Layout.VIDEO -> videoPlaceholder("Video toàn màn hình")
            Layout.WEB -> makeWeb(specs[0])
            Layout.SPLIT2, Layout.SPLIT3 -> buildSplitPreview(count())
        }
        canvas.addView(content, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))

        val editable = layout == Layout.SPLIT2 || layout == Layout.SPLIT3 || layout == Layout.WEB
        frameEditor.visibility = if (editable) View.VISIBLE else View.GONE
        if (editable) {
            if (activeFrame >= count()) activeFrame = 0
            rebuildFrameButtons()
            selectFrame(activeFrame)
        }
    }

    private fun buildSplitPreview(n: Int): View {
        val rowView = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Color.BLACK) }
        for (i in 0 until n) {
            val isVideo = specs[i] == CarHub.VIDEO_SENTINEL
            val frame = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(2), dp(2), dp(2), dp(2))
            }
            val header = TextView(this).apply {
                text = "Khung ${i + 1}" + if (isVideo) " • Video" else ""
                textSize = 11f; setTextColor(Color.WHITE)
                setBackgroundColor(0xFF263238.toInt())
                setPadding(dp(6), dp(3), dp(6), dp(3))
                setOnClickListener { selectFrame(i) }
            }
            frame.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            val body = if (isVideo) videoPlaceholder("Video trong máy") else makeWeb(specs[i])
            frame.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            frameViews.add(frame)
            rowView.addView(frame, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                .apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
        }
        return rowView
    }

    private fun videoPlaceholder(label: String) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setBackgroundColor(Color.BLACK)
        addView(TextView(this@PreviewActivity).apply { text = "▶"; textSize = 40f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
        addView(TextView(this@PreviewActivity).apply { text = label; textSize = 13f; setTextColor(0xFFB0BEC5.toInt()); gravity = Gravity.CENTER })
    }

    private fun buildHomePreview(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF0B1E33.toInt(), 0xFF05080F.toInt())
            )
        }
        root.addView(TextClock(this).apply {
            format24Hour = "HH:mm"; format12Hour = "HH:mm"; textSize = 34f
            setTextColor(Color.WHITE); gravity = Gravity.CENTER
        })
        fun tiles(vararg t: Pair<String, Int>): LinearLayout {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0) }
            t.forEach { (label, color) ->
                r.addView(LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                    background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(color) }
                    addView(TextView(this@PreviewActivity).apply { text = label; textSize = 11f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
                    layoutParams = LinearLayout.LayoutParams(dp(58), dp(40)).apply { setMargins(dp(4), 0, dp(4), 0) }
                }, LinearLayout.LayoutParams(dp(58), dp(40)).apply { setMargins(dp(4), 0, dp(4), 0) })
            }
            return r
        }
        root.addView(tiles("YouTube" to 0xFFD32F2F.toInt(), "Web" to 0xFF1976D2.toInt(), "Bản đồ" to 0xFF00838F.toInt()))
        root.addView(tiles("Video" to 0xFF388E3C.toInt(), "2 khung" to 0xFF00796B.toInt(), "Chiếu ĐT" to 0xFF7B1FA2.toInt()))
        return root
    }

    private fun rebuildFrameButtons() {
        frameBtnRow.removeAllViews()
        if (layout == Layout.WEB) {
            frameBtnRow.visibility = View.GONE; activeFrame = 0; return
        }
        frameBtnRow.visibility = View.VISIBLE
        for (i in 0 until count()) {
            frameBtnRow.addView(Button(this).apply {
                text = "Khung ${i + 1}"; isAllCaps = false
                setOnClickListener { selectFrame(i) }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(6) })
        }
    }

    private fun updateFrameButtons() {
        for (i in 0 until frameBtnRow.childCount) {
            (frameBtnRow.getChildAt(i) as? Button)?.alpha = if (i == activeFrame) 1f else 0.5f
        }
    }

    private fun updateFrameBorders() {
        frameViews.forEachIndexed { i, v ->
            v.background = GradientDrawable().apply {
                setColor(Color.BLACK)
                setStroke(dp(2), if (i == activeFrame) 0xFF42A5F5.toInt() else 0x33FFFFFF)
            }
        }
    }

    // ---------------- Lưu / nạp / mở ----------------

    private fun currentSpecs(): List<String> = (0 until count()).map { specs[it] }

    private fun savePreset() {
        if (layout != Layout.SPLIT2 && layout != Layout.SPLIT3) {
            toast("Chỉ lưu được bố cục chia khung (2–3 khung)"); return
        }
        val name = nameEdit.text.toString().trim().ifEmpty { "Bố cục ${PresetStore.list(this).size + 1}" }
        PresetStore.save(this, SplitPreset(name, count(), currentSpecs()))
        rebuildPresets()
        toast("Đã lưu \"$name\"")
    }

    private fun openOnCar() {
        when (layout) {
            Layout.HOME -> CarHub.openHome()
            Layout.MAP -> CarHub.openMap(this)
            Layout.VIDEO -> CarHub.openVideo(this)
            Layout.WEB -> CarHub.openWeb(specs[0])
            Layout.SPLIT2, Layout.SPLIT3 -> CarHub.applySplit(this, count(), currentSpecs())
        }
        toast(if (CarHub.isCarConnected) "Đã mở trên màn hình xe" else "Đã đặt – sẽ hiện khi kết nối xe")
    }

    private fun loadPreset(p: SplitPreset) {
        layout = if (p.count >= 3) Layout.SPLIT3 else Layout.SPLIT2
        for (i in 0 until 3) specs[i] = p.specs.getOrElse(i) { "https://www.google.com" }
        activeFrame = 0
        nameEdit.setText(p.name)
        render()
    }

    private fun rebuildPresets() {
        presetBox.removeAllViews()
        val presets = PresetStore.list(this)
        if (presets.isEmpty()) {
            presetBox.addView(note("Chưa có bố cục mẫu nào.")); return
        }
        presets.forEach { preset ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val hasVideo = preset.specs.any { it == CarHub.VIDEO_SENTINEL }
            row.addView(TextView(this).apply {
                text = "${preset.name}  (${preset.count} khung${if (hasVideo) ", có video" else ""})"; textSize = 14f
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(btn("Xem") { loadPreset(preset) }, wrapLp())
            row.addView(btn("Mở") {
                CarHub.openSplitPreset(this, preset)
                toast(if (CarHub.isCarConnected) "Đã mở trên xe" else "Sẽ hiện khi kết nối xe")
            }, wrapLp())
            row.addView(btn("Xoá") { PresetStore.delete(this, preset.name); rebuildPresets() }, wrapLp())
            presetBox.addView(row, lp())
        }
    }

    private fun wrapLp() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { marginStart = dp(4) }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
}
