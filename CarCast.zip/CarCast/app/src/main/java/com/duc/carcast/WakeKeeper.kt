package com.duc.carcast

import android.content.Context
import android.os.PowerManager

/**
 * Giữ CPU chạy khi điện thoại tắt màn hình, để nội dung của CarCast vẫn được
 * vẽ lên màn hình xe và nhận cảm ứng. Chỉ là PARTIAL_WAKE_LOCK (không bật
 * màn hình điện thoại), nên điện thoại vẫn tắt màn như bình thường.
 */
object WakeKeeper {
    private var lock: PowerManager.WakeLock? = null

    fun update(ctx: Context) {
        if (Prefs.keepAwake(ctx) && CarHub.isCarConnected) acquireLock(ctx) else release()
    }

    private fun acquireLock(ctx: Context) {
        if (lock?.isHeld == true) return
        val pm = ctx.applicationContext.getSystemService(PowerManager::class.java) ?: return
        val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "CarCast:session")
        wl.setReferenceCounted(false)
        wl.acquire()
        lock = wl
    }

    fun release() {
        try {
            lock?.let { if (it.isHeld) it.release() }
        } catch (_: Exception) {
        }
        lock = null
    }
}
