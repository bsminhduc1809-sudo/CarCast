package com.duc.carcast.nav

import android.graphics.drawable.Drawable

/**
 * Giữ chỉ dẫn điều hướng mới nhất đọc được từ thông báo của Google Maps/VietMap.
 * NavNotificationListener ghi vào đây (trên main thread) và gọi [onChanged];
 * CarPresentation đọc để vẽ thanh chỉ dẫn trên màn hình xe.
 */
object NavController {
    @Volatile var active = false
        private set
    @Volatile var primary = ""
        private set
    @Volatile var secondary = ""
        private set
    @Volatile var eta = ""
        private set
    @Volatile var icon: Drawable? = null
        private set
    @Volatile var source = ""
        private set

    /** CarPresentation đăng ký để được báo khi chỉ dẫn thay đổi. */
    var onChanged: (() -> Unit)? = null

    fun set(primary: String, secondary: String, eta: String, icon: Drawable?, source: String) {
        this.active = true
        this.primary = primary
        this.secondary = secondary
        this.eta = eta
        this.icon = icon
        this.source = source
        onChanged?.invoke()
    }

    fun clear() {
        if (!active) return
        active = false
        primary = ""; secondary = ""; eta = ""; icon = null; source = ""
        onChanged?.invoke()
    }
}
