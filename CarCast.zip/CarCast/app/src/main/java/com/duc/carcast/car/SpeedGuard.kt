package com.duc.carcast.car

import android.Manifest
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import androidx.car.app.CarContext
import androidx.car.app.hardware.CarHardwareManager
import androidx.car.app.hardware.common.CarValue
import androidx.car.app.hardware.common.OnCarDataAvailableListener
import androidx.car.app.hardware.info.Speed
import androidx.core.content.ContextCompat
import com.duc.carcast.Prefs

/**
 * Khóa an toàn: khi xe chạy nhanh hơn ngưỡng (mặc định 5 km/h) trong 3 giây thì
 * báo "đang di chuyển"; khi xe dưới 3 km/h trong 5 giây thì mở lại.
 * Ưu tiên tốc độ do xe báo qua Android Auto, dự phòng bằng GPS điện thoại.
 */
class SpeedGuard(
    private val carContext: CarContext,
    private val onMovingChanged: (Boolean) -> Unit,
) : LocationListener {

    private var moving = false
    private var fastSince = 0L
    private var slowSince = 0L
    private var carSpeedKmh = -1f
    private var gpsSpeedKmh = -1f
    private var started = false

    private val speedListener = OnCarDataAvailableListener<Speed> { speed ->
        val v = pick(speed.displaySpeedMetersPerSecond) ?: pick(speed.rawSpeedMetersPerSecond)
        if (v != null) {
            carSpeedKmh = v * 3.6f
            evaluate()
        }
    }

    private fun pick(cv: CarValue<Float>): Float? =
        if (cv.status == CarValue.STATUS_SUCCESS) cv.value else null

    fun start() {
        if (started || !Prefs.speedLock(carContext)) return
        started = true
        try {
            carContext.getCarService(CarHardwareManager::class.java).carInfo
                .addSpeedListener(ContextCompat.getMainExecutor(carContext), speedListener)
        } catch (t: Throwable) {
            Log.w(TAG, "Không đọc được tốc độ xe, dùng GPS", t)
        }
        if (ContextCompat.checkSelfPermission(carContext, Manifest.permission.ACCESS_FINE_LOCATION)
            == PackageManager.PERMISSION_GRANTED
        ) {
            try {
                carContext.getSystemService(LocationManager::class.java)
                    ?.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this, Looper.getMainLooper())
            } catch (t: Throwable) {
                Log.w(TAG, "Không bật được GPS", t)
            }
        }
    }

    fun stop() {
        if (!started) return
        started = false
        try {
            carContext.getCarService(CarHardwareManager::class.java).carInfo
                .removeSpeedListener(speedListener)
        } catch (_: Throwable) {
        }
        try {
            carContext.getSystemService(LocationManager::class.java)?.removeUpdates(this)
        } catch (_: Throwable) {
        }
    }

    private fun evaluate() {
        val kmh = maxOf(carSpeedKmh, gpsSpeedKmh)
        if (kmh < 0) return
        val now = SystemClock.elapsedRealtime()
        val limit = Prefs.speedLimit(carContext)
        if (kmh > limit) {
            slowSince = 0L
            if (fastSince == 0L) fastSince = now
            if (!moving && now - fastSince >= 3_000) setMoving(true)
        } else if (kmh < 3f) {
            fastSince = 0L
            if (slowSince == 0L) slowSince = now
            if (moving && now - slowSince >= 5_000) setMoving(false)
        }
    }

    private fun setMoving(m: Boolean) {
        moving = m
        onMovingChanged(m)
    }

    // ---- LocationListener (khai báo đủ để chạy trên Android 10) ----
    override fun onLocationChanged(location: Location) {
        if (!location.hasSpeed()) return
        gpsSpeedKmh = location.speed * 3.6f
        evaluate()
    }

    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}

    @Deprecated("Deprecated in Java")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}

    companion object {
        private const val TAG = "SpeedGuard"
    }
}
