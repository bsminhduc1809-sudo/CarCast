package com.duc.carcast

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import com.duc.carcast.car.CarPresentation
import com.duc.carcast.car.CarRenderer
import com.duc.carcast.mirror.MirrorController
import com.duc.carcast.phone.MainActivity
import java.net.URLEncoder

/**
 * Điểm trung tâm nối giữa: màn hình xe (CarRenderer/CarPresentation),
 * ứng dụng trên điện thoại (MainActivity) và dịch vụ chiếu màn hình.
 * Mọi hàm phải gọi trên main thread.
 */
object CarHub {
    enum class Mode { HOME, WEB, VIDEO, MIRROR, SPLIT }

    private val main = Handler(Looper.getMainLooper())

    var renderer: CarRenderer? = null
    val presentation: CarPresentation? get() = renderer?.presentation
    val isCarConnected: Boolean get() = renderer != null

    /** Chế độ đang/đã hiển thị — để khôi phục khi bề mặt xe được tạo lại. */
    var mode: Mode = Mode.HOME
    var videoUri: Uri? = null
    var videoPositionMs: Long = 0L

    /** Chế độ chia khung: số khung (2–3), địa chỉ từng khung, khung đang chọn. */
    var splitCount: Int = 2
        private set
    val splitUrls: ArrayList<String> = ArrayList()
    var splitActive: Int = 0
        private set

    /** true khi xe đang chạy và khóa an toàn đang bật. */
    var blocked: Boolean = false
        private set

    /** Lắng nghe thay đổi trạng thái để cập nhật giao diện trên điện thoại. */
    var onStateChanged: (() -> Unit)? = null

    fun notifyChanged() = main.post { onStateChanged?.invoke() }

    fun setBlocked(b: Boolean) {
        if (blocked == b) return
        blocked = b
        presentation?.setBlocked(b)
        renderer?.refreshMirror()
        notifyChanged()
    }

    fun openHome() {
        mode = Mode.HOME
        if (MirrorController.isActive) renderer?.refreshMirror()
        presentation?.showHome()
    }

    fun openWeb(url: String) {
        mode = Mode.WEB
        renderer?.refreshMirror()
        presentation?.openWeb(url)
    }

    fun openYouTube(ctx: Context) = openWeb(Prefs.homeUrl(ctx))

    fun openVideo(ctx: Context, uri: Uri? = null) {
        val target = uri ?: videoUri ?: Prefs.lastVideo(ctx)?.let { Uri.parse(it) }
        if (target == null) {
            presentation?.toast("Chưa có video – hãy chọn video trên điện thoại")
            return
        }
        if (target != videoUri) videoPositionMs = 0L
        videoUri = target
        mode = Mode.VIDEO
        renderer?.refreshMirror()
        presentation?.playVideo(target, videoPositionMs)
    }

    // ---------------- Chia 2–3 khung ----------------

    fun openSplit(ctx: Context, count: Int) {
        splitCount = count.coerceIn(2, 3)
        if (splitUrls.isEmpty()) {
            splitUrls.addAll(
                listOf(
                    Prefs.homeUrl(ctx),
                    "https://www.google.com/maps",
                    "https://www.google.com"
                )
            )
        }
        while (splitUrls.size < 3) splitUrls.add("https://www.google.com")
        if (splitActive >= splitCount) splitActive = 0
        mode = Mode.SPLIT
        renderer?.refreshMirror()
        if (isCarConnected) {
            presentation?.showSplit()
        } else {
            presentation?.toast("Chưa kết nối Android Auto")
        }
    }

    fun setSplitActive(i: Int) {
        splitActive = i.coerceIn(0, splitCount - 1)
    }

    fun setSplitUrl(i: Int, url: String) {
        if (i in 0 until splitUrls.size) splitUrls[i] = url
    }

    /** Văn bản nhập từ bàn phím trên xe: URL → mở web, còn lại → tìm trên YouTube. */
    fun submitText(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        val looksLikeUrl = !t.contains(' ') && (t.startsWith("http") || t.contains('.'))
        val url = when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            looksLikeUrl -> "https://$t"
            else -> "https://m.youtube.com/results?search_query=" + URLEncoder.encode(t, "UTF-8")
        }
        if (mode == Mode.SPLIT) presentation?.loadIntoActive(url) else openWeb(url)
    }

    fun back() {
        if (mode == Mode.MIRROR) {
            MirrorController.globalBack()
            return
        }
        val p = presentation ?: return
        if (!p.handleBack()) openHome()
    }

    fun togglePlay() {
        if (mode == Mode.MIRROR) return
        presentation?.togglePlay()
    }

    /**
     * Bắt đầu chiếu màn hình điện thoại. Android bắt buộc người dùng xác nhận
     * trên điện thoại, nên nếu chưa có phiên chiếu thì mở ứng dụng trên điện thoại
     * (và gửi thông báo dự phòng).
     */
    fun requestMirror(ctx: Context) {
        if (MirrorController.isActive) {
            mode = Mode.MIRROR
            renderer?.refreshMirror()
            return
        }
        presentation?.toast("Xác nhận \"Bắt đầu chiếu\" trên điện thoại")
        val intent = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra(MainActivity.EXTRA_REQUEST_MIRROR, true)
        try {
            ctx.startActivity(intent)
        } catch (_: Exception) {
        }
        postMirrorNotification(ctx, intent)
    }

    private fun postMirrorNotification(ctx: Context, intent: Intent) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(
            NotificationChannel(CH_ACTION, "Yêu cầu từ ô tô", NotificationManager.IMPORTANCE_HIGH)
        )
        val pi = PendingIntent.getActivity(
            ctx, 1, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = android.app.Notification.Builder(ctx, CH_ACTION)
            .setSmallIcon(R.drawable.ic_cast)
            .setContentTitle("Chiếu màn hình lên ô tô")
            .setContentText("Chạm để cho phép chiếu màn hình điện thoại")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        try {
            nm.notify(NOTIF_MIRROR_REQUEST, n)
        } catch (_: SecurityException) {
        }
    }

    fun cancelMirrorRequestNotification(ctx: Context) {
        ctx.getSystemService(NotificationManager::class.java)?.cancel(NOTIF_MIRROR_REQUEST)
    }

    private const val CH_ACTION = "car_requests"
    private const val NOTIF_MIRROR_REQUEST = 4001
}
