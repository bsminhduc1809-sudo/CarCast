package com.duc.carcast.car

import android.annotation.SuppressLint
import android.app.Presentation
import android.content.Context
import android.graphics.Color
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.TypedValue
import android.view.Display
import android.view.Gravity
import android.view.InputDevice
import android.view.MotionEvent
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import com.duc.carcast.CarHub
import com.duc.carcast.Prefs

/**
 * Giao diện hiển thị trên màn hình xe (chạy trên VirtualDisplay).
 * Gồm: màn hình chính, trình duyệt web, trình phát video, chế độ chia 2–3 khung,
 * và lớp phủ khóa an toàn khi xe đang chạy.
 */
class CarPresentation(outer: Context, display: Display) : Presentation(outer, display) {

    private val handler = Handler(Looper.getMainLooper())

    private lateinit var root: FrameLayout
    private lateinit var content: FrameLayout
    private lateinit var blockOverlay: TextView
    private lateinit var toastView: TextView

    private var homeView: View? = null
    private var webView: WebView? = null
    private var videoContainer: FrameLayout? = null
    private var videoSurface: SurfaceView? = null
    private var player: ExoPlayer? = null

    private var splitContainer: LinearLayout? = null
    private val panes = ArrayList<Pane>()

    private var fullscreenView: View? = null
    private var fullscreenCallback: WebChromeClient.CustomViewCallback? = null

    // ---- trạng thái kéo (scroll) đang mô phỏng ----
    private var dragDownTime = 0L
    private var dragX = 0f
    private var dragY = 0f
    private val endDrag = Runnable {
        if (dragDownTime != 0L) {
            dispatch(MotionEvent.ACTION_UP, dragX, dragY, dragDownTime)
            dragDownTime = 0L
        }
    }

    private fun dp(v: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), context.resources.displayMetrics
    ).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(context).apply { setBackgroundColor(Color.BLACK) }
        content = FrameLayout(context)
        root.addView(content, match())

        toastView = TextView(context).apply {
            setTextColor(Color.WHITE)
            textSize = 18f
            setPadding(dp(16), dp(10), dp(16), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(20).toFloat()
                setColor(0xDD222222.toInt())
            }
            visibility = View.GONE
        }
        root.addView(
            toastView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).apply { bottomMargin = dp(24) }
        )

        blockOverlay = TextView(context).apply {
            text = "Xe đang di chuyển\n\nVideo và web tạm dừng để bạn tập trung lái xe.\nNội dung sẽ tiếp tục khi xe dừng."
            gravity = Gravity.CENTER
            textSize = 24f
            setTextColor(Color.WHITE)
            setBackgroundColor(0xF2000000.toInt())
            isClickable = true // chặn chạm xuống nội dung bên dưới
            visibility = View.GONE
        }
        root.addView(blockOverlay, match())

        setContentView(root)
        window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

        // Khôi phục chế độ trước đó (ví dụ khi quay lại ứng dụng trên xe)
        when (CarHub.mode) {
            CarHub.Mode.WEB -> openWeb(Prefs.lastUrl(context) ?: Prefs.homeUrl(context))
            CarHub.Mode.VIDEO -> CarHub.videoUri?.let { playVideo(it, CarHub.videoPositionMs) } ?: showHome()
            CarHub.Mode.SPLIT -> showSplit()
            else -> showHome()
        }
        setBlocked(CarHub.blocked)
    }

    override fun onStop() {
        player?.let {
            CarHub.videoPositionMs = it.currentPosition
            it.release()
        }
        player = null
        webView?.let {
            Prefs.setLastUrl(context, it.url)
            it.stopLoading()
            it.destroy()
        }
        webView = null
        destroyPanes()
        handler.removeCallbacksAndMessages(null)
        super.onStop()
    }

    private fun match() = FrameLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
    )

    /** Chừa lề cho phần bị thanh điều khiển của Android Auto che. */
    fun setVisibleArea(area: Rect, w: Int, h: Int) {
        if (!::content.isInitialized || area.isEmpty()) return
        content.setPadding(area.left, area.top, (w - area.right).coerceAtLeast(0), (h - area.bottom).coerceAtLeast(0))
    }

    private fun setContent(v: View) {
        exitFullscreen()
        if (v !== splitContainer) pausePanes()
        for (i in 0 until content.childCount) content.getChildAt(i).visibility = View.GONE
        if (v.parent == null) content.addView(v, match())
        v.visibility = View.VISIBLE
    }

    // ================= MÀN HÌNH CHÍNH =================

    fun showHome() {
        player?.pause()
        pauseWebMedia()
        setContent(homeView ?: buildHome().also { homeView = it })
    }

    private fun buildHome(): View {
        val col = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF0B1E33.toInt(), 0xFF05080F.toInt())
            )
        }
        col.addView(TextClock(context).apply {
            format24Hour = "HH:mm"
            format12Hour = "HH:mm"
            textSize = 72f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            gravity = Gravity.CENTER
        })
        col.addView(TextClock(context).apply {
            format24Hour = "EEEE, dd/MM/yyyy"
            format12Hour = "EEEE, dd/MM/yyyy"
            textSize = 20f
            setTextColor(0xFFB0BEC5.toInt())
            gravity = Gravity.CENTER
        })
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(24), 0, 0)
        }
        row.addView(tile("▶", "YouTube", 0xFFD32F2F.toInt()) { CarHub.openYouTube(context) })
        row.addView(tile("🌐", "Web", 0xFF1976D2.toInt()) {
            CarHub.openWeb(Prefs.lastUrl(context) ?: "https://www.google.com")
        })
        row.addView(tile("🎬", "Video", 0xFF388E3C.toInt()) { CarHub.openVideo(context) })
        row.addView(tile("▣", "2 khung", 0xFF00796B.toInt()) { CarHub.openSplit(context, 2) })
        row.addView(tile("📱", "Chiếu ĐT", 0xFF7B1FA2.toInt()) { CarHub.requestMirror(context) })
        col.addView(row)
        return col
    }

    private fun tile(icon: String, label: String, color: Int, onClick: () -> Unit): View {
        val size = dp(116)
        return LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat()
                setColor(color)
            }
            addView(TextView(context).apply {
                text = icon; textSize = 38f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            })
            addView(TextView(context).apply {
                text = label; textSize = 17f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            })
            layoutParams = LinearLayout.LayoutParams(size, size).apply {
                setMargins(dp(10), 0, dp(10), 0)
            }
            isClickable = true
            setOnClickListener { onClick() }
        }
    }

    // ================= TRÌNH DUYỆT WEB (CHẾ ĐỘ ĐƠN) =================

    @SuppressLint("SetJavaScriptEnabled")
    private fun newWebView(allowFullscreen: Boolean, onUrl: (String?) -> Unit): WebView =
        WebView(context).also { wv ->
            wv.settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                mediaPlaybackRequiresUserGesture = false
                loadWithOverviewMode = true
                useWideViewPort = true
                builtInZoomControls = false
            }
            wv.webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val scheme = request.url.scheme ?: return true
                    return scheme != "http" && scheme != "https"
                }

                override fun onPageFinished(view: WebView, url: String?) = onUrl(url)
            }
            if (allowFullscreen) {
                wv.webChromeClient = object : WebChromeClient() {
                    override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                        exitFullscreen()
                        fullscreenView = view
                        fullscreenCallback = callback
                        root.addView(view, 1, match())
                    }

                    override fun onHideCustomView() = exitFullscreen()
                }
            } else {
                wv.webChromeClient = WebChromeClient()
            }
        }

    private fun exitFullscreen() {
        fullscreenView?.let { root.removeView(it) }
        fullscreenView = null
        fullscreenCallback?.onCustomViewHidden()
        fullscreenCallback = null
    }

    fun openWeb(url: String) {
        player?.pause()
        val wv = webView ?: newWebView(true) { Prefs.setLastUrl(context, it) }.also { webView = it }
        setContent(wv)
        wv.onResume()
        if (wv.url != url) wv.loadUrl(url)
    }

    private fun pauseWebMedia() {
        webView?.evaluateJavascript(
            "document.querySelectorAll('video,audio').forEach(function(m){m.pause();});", null
        )
    }

    // ================= CHIA 2–3 KHUNG =================

    /** Một khung web độc lập trong chế độ chia màn hình. */
    private inner class Pane(val index: Int) {
        val web: WebView = newWebView(false) { url -> CarHub.setSplitUrl(index, url ?: return@newWebView) }
        private val title = TextView(context).apply {
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(dp(8), dp(4), dp(8), dp(4))
            maxLines = 1
        }
        val frame: LinearLayout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(3), dp(3), dp(3), dp(3))
            val bar = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundColor(0xFF263238.toInt())
                addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                addView(barBtn("⌂") { web.loadUrl(Prefs.homeUrl(context)) })
                addView(barBtn("↻") { web.reload() })
            }
            addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }

        private fun barBtn(label: String, onClick: () -> Unit) = TextView(context).apply {
            text = label
            textSize = 18f
            setTextColor(Color.WHITE)
            setPadding(dp(14), dp(4), dp(14), dp(4))
            isClickable = true
            setOnClickListener { onClick() }
        }

        fun load(url: String) {
            title.text = "Khung ${index + 1}"
            if (web.url != url) web.loadUrl(url)
        }

        fun setActive(active: Boolean) {
            frame.background = GradientDrawable().apply {
                setColor(Color.BLACK)
                setStroke(dp(3), if (active) 0xFF42A5F5.toInt() else Color.TRANSPARENT)
            }
            title.setTextColor(if (active) 0xFF90CAF9.toInt() else Color.WHITE)
        }

        fun setMuted(muted: Boolean) {
            web.evaluateJavascript(
                "document.querySelectorAll('video,audio').forEach(function(m){m.muted=$muted;});", null
            )
        }

        fun pause() {
            web.evaluateJavascript(
                "document.querySelectorAll('video,audio').forEach(function(m){m.pause();});", null
            )
            web.onPause()
        }

        fun resume() = web.onResume()

        fun destroy() {
            web.stopLoading()
            web.destroy()
        }
    }

    fun showSplit() {
        player?.pause()
        pauseWebMedia()
        val container = splitContainer ?: LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.BLACK)
        }.also { splitContainer = it }

        if (panes.size != CarHub.splitCount) {
            destroyPanes()
            container.removeAllViews()
            for (i in 0 until CarHub.splitCount) {
                val pane = Pane(i)
                panes.add(pane)
                container.addView(
                    pane.frame,
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                        .apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }
                )
            }
        }
        setContent(container)
        panes.forEachIndexed { i, pane ->
            pane.resume()
            pane.load(CarHub.splitUrls[i])
        }
        setActivePane(CarHub.splitActive.coerceIn(0, panes.size - 1))
        if (CarHub.blocked) pausePanes()
    }

    fun loadIntoActive(url: String) {
        val i = CarHub.splitActive
        if (i in panes.indices) {
            CarHub.setSplitUrl(i, url)
            panes[i].load(url)
        }
    }

    private fun setActivePane(i: Int) {
        if (panes.isEmpty()) return
        val active = i.coerceIn(0, panes.size - 1)
        CarHub.setSplitActive(active)
        panes.forEachIndexed { idx, pane ->
            pane.setActive(idx == active)
            if (!CarHub.blocked) pane.setMuted(idx != active)
        }
    }

    private fun paneAt(x: Float, y: Float): Int {
        val loc = IntArray(2)
        panes.forEachIndexed { idx, pane ->
            pane.frame.getLocationInWindow(loc)
            if (x >= loc[0] && x <= loc[0] + pane.frame.width &&
                y >= loc[1] && y <= loc[1] + pane.frame.height
            ) return idx
        }
        return -1
    }

    private fun pausePanes() = panes.forEach { it.pause() }

    private fun destroyPanes() {
        panes.forEach { it.destroy() }
        panes.clear()
    }

    // ================= TRÌNH PHÁT VIDEO =================

    private fun ensureVideoViews(): FrameLayout = videoContainer ?: FrameLayout(context).also { box ->
        box.setBackgroundColor(Color.BLACK)
        val sv = SurfaceView(context)
        box.addView(sv, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER
        ))
        videoSurface = sv

        val bar = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(0x88000000.toInt())
            setPadding(0, dp(6), 0, dp(6))
        }
        bar.addView(ctrl("⏪ 10s") { player?.let { it.seekTo((it.currentPosition - 10_000).coerceAtLeast(0)) } })
        bar.addView(ctrl("⏯") { togglePlay() })
        bar.addView(ctrl("10s ⏩") { player?.let { it.seekTo(it.currentPosition + 10_000) } })
        bar.addView(ctrl("✕") { CarHub.openHome() })
        box.addView(bar, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM
        ))
        videoContainer = box
    }

    private fun ctrl(label: String, onClick: () -> Unit) = TextView(context).apply {
        text = label
        textSize = 22f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(dp(24), dp(8), dp(24), dp(8))
        isClickable = true
        setOnClickListener { onClick() }
    }

    fun playVideo(uri: Uri, startMs: Long) {
        pauseWebMedia()
        val box = ensureVideoViews()
        setContent(box)
        val p = player ?: ExoPlayer.Builder(context).build().also { ep ->
            ep.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                true
            )
            ep.addListener(object : Player.Listener {
                override fun onVideoSizeChanged(videoSize: VideoSize) = fitVideo(videoSize)
                override fun onPlayerError(error: PlaybackException) {
                    toast("Không phát được video: ${error.errorCodeName}")
                }
            })
            player = ep
        }
        p.setVideoSurfaceView(videoSurface)
        p.setMediaItem(MediaItem.fromUri(uri), startMs)
        p.prepare()
        if (!CarHub.blocked) p.play()
    }

    private fun fitVideo(size: VideoSize) {
        val sv = videoSurface ?: return
        val box = videoContainer ?: return
        if (size.width == 0 || size.height == 0 || box.width == 0 || box.height == 0) return
        val ratio = size.width * size.pixelWidthHeightRatio / size.height
        var w = box.width
        var h = (w / ratio).toInt()
        if (h > box.height) {
            h = box.height
            w = (h * ratio).toInt()
        }
        sv.layoutParams = FrameLayout.LayoutParams(w, h, Gravity.CENTER)
    }

    fun togglePlay() {
        val p = player
        when (CarHub.mode) {
            CarHub.Mode.VIDEO -> if (p != null) {
                if (p.isPlaying) p.pause() else if (!CarHub.blocked) p.play()
            }
            CarHub.Mode.WEB -> {
                if (CarHub.blocked) return
                webView?.evaluateJavascript(TOGGLE_JS, null)
            }
            CarHub.Mode.SPLIT -> {
                if (CarHub.blocked) return
                panes.getOrNull(CarHub.splitActive)?.web?.evaluateJavascript(TOGGLE_JS, null)
            }
            else -> {}
        }
    }

    fun pauseAll() {
        player?.pause()
        pauseWebMedia()
        pausePanes()
    }

    // ================= ĐIỀU HƯỚNG / KHÓA / THÔNG BÁO =================

    /** @return true nếu đã xử lý nút quay lại. */
    fun handleBack(): Boolean {
        if (fullscreenView != null) {
            exitFullscreen(); return true
        }
        if (CarHub.mode == CarHub.Mode.SPLIT) {
            val pane = panes.getOrNull(CarHub.splitActive) ?: return false
            if (pane.web.canGoBack()) {
                pane.web.goBack(); return true
            }
            return false
        }
        val wv = webView
        if (CarHub.mode == CarHub.Mode.WEB && wv != null && wv.canGoBack()) {
            wv.goBack(); return true
        }
        return false
    }

    fun setBlocked(b: Boolean) {
        if (!::blockOverlay.isInitialized) return
        blockOverlay.visibility = if (b) View.VISIBLE else View.GONE
        if (b) pauseAll()
    }

    fun toast(msg: String) {
        if (!::toastView.isInitialized) return
        toastView.text = msg
        toastView.visibility = View.VISIBLE
        handler.removeCallbacks(hideToast)
        handler.postDelayed(hideToast, 3500)
    }

    private val hideToast = Runnable { toastView.visibility = View.GONE }

    // ================= MÔ PHỎNG CẢM ỨNG =================

    fun injectTap(x: Float, y: Float) {
        endDrag.run()
        if (CarHub.mode == CarHub.Mode.SPLIT) {
            val idx = paneAt(x, y)
            if (idx >= 0 && idx != CarHub.splitActive) setActivePane(idx)
        }
        val down = SystemClock.uptimeMillis()
        dispatch(MotionEvent.ACTION_DOWN, x, y, down)
        handler.postDelayed({ dispatch(MotionEvent.ACTION_UP, x, y, down) }, 60)
    }

    /** Android Auto gửi từng đoạn kéo; ghép lại thành một thao tác kéo liên tục. */
    fun injectScroll(distanceX: Float, distanceY: Float) {
        val decor = window?.decorView ?: return
        if (dragDownTime == 0L) {
            dragDownTime = SystemClock.uptimeMillis()
            val anchor = scrollAnchor(decor)
            dragX = anchor.first
            dragY = anchor.second
            dispatch(MotionEvent.ACTION_DOWN, dragX, dragY, dragDownTime)
        }
        dragX = (dragX - distanceX).coerceIn(1f, decor.width - 1f)
        dragY = (dragY - distanceY).coerceIn(1f, decor.height - 1f)
        dispatch(MotionEvent.ACTION_MOVE, dragX, dragY, dragDownTime)
        handler.removeCallbacks(endDrag)
        handler.postDelayed(endDrag, 120)
    }

    /** Điểm neo khi kéo: giữa khung đang chọn (chế độ chia), hoặc giữa màn hình. */
    private fun scrollAnchor(decor: View): Pair<Float, Float> {
        if (CarHub.mode == CarHub.Mode.SPLIT) {
            panes.getOrNull(CarHub.splitActive)?.let { pane ->
                val loc = IntArray(2)
                pane.frame.getLocationInWindow(loc)
                return (loc[0] + pane.frame.width / 2f) to (loc[1] + pane.frame.height / 2f)
            }
        }
        return decor.width / 2f to decor.height / 2f
    }

    private fun dispatch(action: Int, x: Float, y: Float, downTime: Long) {
        val decor = window?.decorView ?: return
        val ev = MotionEvent.obtain(downTime, SystemClock.uptimeMillis(), action, x, y, 0)
        ev.source = InputDevice.SOURCE_TOUCHSCREEN
        decor.dispatchTouchEvent(ev)
        ev.recycle()
    }

    companion object {
        private const val TOGGLE_JS =
            "(function(){var v=document.querySelector('video');if(v){if(v.paused)v.play();else v.pause();}})();"
    }
}
