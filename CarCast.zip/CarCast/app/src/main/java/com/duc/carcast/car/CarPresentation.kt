package com.duc.carcast.car

import android.Manifest
import android.annotation.SuppressLint
import android.app.Presentation
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.TypedValue
import android.view.Display
import android.view.Gravity
import android.view.InputDevice
import android.view.MotionEvent
import android.view.Surface
import android.view.SurfaceView
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import com.duc.carcast.CarHub
import com.duc.carcast.Prefs
import com.duc.carcast.mirror.MirrorController
import com.duc.carcast.nav.NavController

/**
 * Giao diện hiển thị trên màn hình xe (chạy trên VirtualDisplay).
 * Nội dung vẽ tràn viền (full màn hình); chỉ các thanh điều khiển được chừa lề
 * theo vùng hiển thị của Android Auto.
 */
class CarPresentation(outer: Context, display: Display) : Presentation(outer, display) {

    private val handler = Handler(Looper.getMainLooper())

    private lateinit var root: FrameLayout
    private lateinit var content: FrameLayout
    private lateinit var blockOverlay: TextView
    private lateinit var toastView: TextView

    private var insetTop = 0
    private var insetBottom = 0

    private var mapVisible = false
    private var locActive = false
    private var lastSpeedKmh = -1f
    private lateinit var navBar: LinearLayout
    private lateinit var navIcon: ImageView
    private lateinit var navPrimary: TextView
    private lateinit var navSecondary: TextView
    private lateinit var speedChip: LinearLayout
    private lateinit var speedValue: TextView

    private var homeView: View? = null
    private var webView: WebView? = null
    private var videoContainer: FrameLayout? = null
    private var videoSurface: SurfaceView? = null
    private var videoBar: View? = null
    private var player: ExoPlayer? = null

    private var splitContainer: LinearLayout? = null
    private val panes = ArrayList<Pane>()

    private var mapBox: FrameLayout? = null
    private var mapWebView: WebView? = null
    private var locMgr: LocationManager? = null

    private var mirrorBox: FrameLayout? = null
    private var mirrorTv: TextureView? = null
    private var mirrorSurface: Surface? = null
    private var mirrorShowing = false
    private var mirrorViewW = 0
    private var mirrorViewH = 0
    private var mirrorPhoneW = 0
    private var mirrorPhoneH = 0
    private var mScrollActive = false
    private var mStartX = 0f
    private var mStartY = 0f
    private var mCurX = 0f
    private var mCurY = 0f

    private var fullscreenView: View? = null
    private var fullscreenCallback: WebChromeClient.CustomViewCallback? = null

    // ---- trạng thái kéo (scroll) đang mô phỏng cho nội dung của app ----
    private var dragDownTime = 0L
    private var dragX = 0f
    private var dragY = 0f
    private val endDrag = Runnable {
        if (dragDownTime != 0L) {
            dispatch(MotionEvent.ACTION_UP, dragX, dragY, dragDownTime)
            dragDownTime = 0L
        }
    }

    private val endMirrorScroll = Runnable {
        if (mScrollActive) {
            mScrollActive = false
            val a = mapToPhone(mStartX, mStartY)
            val b = mapToPhone(mCurX, mCurY)
            if (a != null && b != null) MirrorController.swipe(a.first, a.second, b.first, b.second)
        }
    }

    private fun dp(v: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), context.resources.displayMetrics
    ).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(context).apply { setBackgroundColor(Color.BLACK) }
        content = FrameLayout(context)
        root.addView(content, match())

        toastView = TextView(context).apply {
            setTextColor(Color.WHITE)
            textSize = 18f
            setPadding(dp(16), dp(10), dp(16), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(20).toFloat()
                setColor(0xDD222222.toInt())
            }
            visibility = View.GONE
        }
        root.addView(
            toastView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).apply { bottomMargin = dp(24) }
        )

        blockOverlay = TextView(context).apply {
            text = "Xe đang di chuyển\n\nVideo và web tạm dừng để bạn tập trung lái xe.\nNội dung sẽ tiếp tục khi xe dừng."
            gravity = Gravity.CENTER
            textSize = 24f
            setTextColor(Color.WHITE)
            setBackgroundColor(0xF2000000.toInt())
            isClickable = true
            visibility = View.GONE
        }
        root.addView(blockOverlay, match())

        // Chỉ dẫn + HUD nằm TRÊN lớp khóa an toàn để vẫn thấy khi xe đang chạy.
        buildNavOverlay()
        buildSpeedChip()

        setContentView(root)
        window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

        when (CarHub.mode) {
            CarHub.Mode.WEB -> openWeb(Prefs.lastUrl(context) ?: Prefs.homeUrl(context))
            CarHub.Mode.VIDEO -> CarHub.videoUri?.let { playVideo(it, CarHub.videoPositionMs) } ?: showHome()
            CarHub.Mode.SPLIT -> showSplit()
            CarHub.Mode.MAP -> showMap()
            else -> showHome()
        }
        setBlocked(CarHub.blocked)
        NavController.onChanged = { updateNavOverlay() }
        updateNavOverlay()
        updateHud()
        updateLocationState()
    }

    override fun onStop() {
        NavController.onChanged = null
        stopLocation()
        player?.let {
            CarHub.videoPositionMs = it.currentPosition
            it.release()
        }
        player = null
        webView?.let {
            Prefs.setLastUrl(context, it.url)
            it.stopLoading(); it.destroy()
        }
        webView = null
        mapWebView?.let { it.stopLoading(); it.destroy() }
        mapWebView = null
        destroyPanes()
        MirrorController.detachSurface()
        mirrorSurface?.release(); mirrorSurface = null
        handler.removeCallbacksAndMessages(null)
        super.onStop()
    }

    private fun match() = FrameLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
    )

    /** Lưu vùng bị thanh điều khiển che; nội dung vẫn tràn viền, chỉ overlay chừa lề. */
    fun setInsets(area: Rect, w: Int, h: Int) {
        if (area.isEmpty()) return
        insetTop = area.top.coerceAtLeast(0)
        insetBottom = (h - area.bottom).coerceAtLeast(0)
        applyInsets()
    }

    private fun applyInsets() {
        if (::toastView.isInitialized) {
            (toastView.layoutParams as? FrameLayout.LayoutParams)?.let {
                it.bottomMargin = insetBottom + dp(24)
                toastView.layoutParams = it
            }
        }
        videoBar?.setPadding(0, dp(6), 0, dp(6) + insetBottom)
        if (::navBar.isInitialized) (navBar.layoutParams as? FrameLayout.LayoutParams)?.let {
            it.topMargin = insetTop + dp(8); navBar.layoutParams = it
        }
        if (::speedChip.isInitialized) (speedChip.layoutParams as? FrameLayout.LayoutParams)?.let {
            it.bottomMargin = insetBottom + dp(12); speedChip.layoutParams = it
        }
    }

    private fun setContent(v: View) {
        exitFullscreen()
        if (v !== splitContainer) pausePanes()
        mapVisible = (v === mapBox)
        if (v !== mirrorBox) {
            mirrorShowing = false
            MirrorController.detachSurface()
        }
        for (i in 0 until content.childCount) content.getChildAt(i).visibility = View.GONE
        if (v.parent == null) content.addView(v, match())
        v.visibility = View.VISIBLE
        if (v === mirrorBox) mirrorShowing = true
        updateLocationState()
    }

    private fun showForCurrentMode() {
        when (CarHub.mode) {
            CarHub.Mode.WEB -> openWeb(Prefs.lastUrl(context) ?: Prefs.homeUrl(context))
            CarHub.Mode.VIDEO -> CarHub.videoUri?.let { playVideo(it, CarHub.videoPositionMs) } ?: showHome()
            CarHub.Mode.SPLIT -> showSplit()
            CarHub.Mode.MAP -> showMap()
            else -> showHome()
        }
    }

    // ================= MÀN HÌNH CHÍNH =================

    fun showHome() {
        player?.pause()
        pauseWebMedia()
        setContent(homeView ?: buildHome().also { homeView = it })
    }

    private fun buildHome(): View {
        val col = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF0B1E33.toInt(), 0xFF05080F.toInt())
            )
        }
        col.addView(TextClock(context).apply {
            format24Hour = "HH:mm"; format12Hour = "HH:mm"
            textSize = 68f; setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            gravity = Gravity.CENTER
        })
        col.addView(TextClock(context).apply {
            format24Hour = "EEEE, dd/MM/yyyy"; format12Hour = "EEEE, dd/MM/yyyy"
            textSize = 19f; setTextColor(0xFFB0BEC5.toInt()); gravity = Gravity.CENTER
        })
        fun rowOf(vararg tiles: View): LinearLayout = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, 0)
            tiles.forEach { addView(it) }
        }
        col.addView(rowOf(
            tile("▶", "YouTube", 0xFFD32F2F.toInt()) { CarHub.openYouTube(context) },
            tile("🌐", "Web", 0xFF1976D2.toInt()) {
                CarHub.openWeb(Prefs.lastUrl(context) ?: "https://www.google.com")
            },
            tile("🗺", "Bản đồ", 0xFF00838F.toInt()) { CarHub.openMap(context) }
        ))
        col.addView(rowOf(
            tile("🎬", "Video", 0xFF388E3C.toInt()) { CarHub.openVideo(context) },
            tile("▣", "2 khung", 0xFF00796B.toInt()) { CarHub.openSplit(context, 2) },
            tile("📱", "Chiếu ĐT", 0xFF7B1FA2.toInt()) { CarHub.requestMirror(context) }
        ))
        return col
    }

    private fun tile(icon: String, label: String, color: Int, onClick: () -> Unit): View {
        val size = dp(108)
        return LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            background = GradientDrawable().apply { cornerRadius = dp(22).toFloat(); setColor(color) }
            addView(TextView(context).apply {
                text = icon; textSize = 34f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            })
            addView(TextView(context).apply {
                text = label; textSize = 16f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            })
            layoutParams = LinearLayout.LayoutParams(size, size).apply { setMargins(dp(8), 0, dp(8), 0) }
            isClickable = true
            setOnClickListener { onClick() }
        }
    }

    // ================= WEBVIEW DÙNG CHUNG =================

    @SuppressLint("SetJavaScriptEnabled")
    private fun newWebView(allowFullscreen: Boolean, onUrl: (String?) -> Unit): WebView =
        WebView(context).also { wv ->
            wv.settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                mediaPlaybackRequiresUserGesture = false
                loadWithOverviewMode = true
                useWideViewPort = true
                builtInZoomControls = false
            }
            wv.webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val scheme = request.url.scheme ?: return true
                    return scheme != "http" && scheme != "https"
                }

                override fun onPageFinished(view: WebView, url: String?) = onUrl(url)
            }
            if (allowFullscreen) {
                wv.webChromeClient = object : WebChromeClient() {
                    override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                        exitFullscreen()
                        fullscreenView = view
                        fullscreenCallback = callback
                        root.addView(view, 1, match())
                    }

                    override fun onHideCustomView() = exitFullscreen()
                }
            } else {
                wv.webChromeClient = WebChromeClient()
            }
        }

    private fun exitFullscreen() {
        fullscreenView?.let { root.removeView(it) }
        fullscreenView = null
        fullscreenCallback?.onCustomViewHidden()
        fullscreenCallback = null
    }

    fun openWeb(url: String) {
        player?.pause()
        val wv = webView ?: newWebView(true) { Prefs.setLastUrl(context, it) }.also { webView = it }
        setContent(wv)
        wv.onResume()
        if (wv.url != url) wv.loadUrl(url)
    }

    private fun pauseWebMedia() {
        webView?.evaluateJavascript(PAUSE_JS, null)
    }

    // ================= BẢN ĐỒ (OSM) =================

    fun showMap() {
        player?.pause(); pauseWebMedia(); pausePanes()
        val box = mapBox ?: FrameLayout(context).apply {
            setBackgroundColor(0xFF0D141E.toInt())
            val wv = newWebView(false) {}.also { mapWebView = it }
            addView(wv, match())
        }.also { mapBox = it }
        setContent(box)
        mapWebView?.let {
            it.onResume()
            if (it.url == null) it.loadUrl("file:///android_asset/map.html")
        }
    }

    private val locListener = object : LocationListener {
        override fun onLocationChanged(location: Location) = pushLocation(location)
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    }

    /** Cần GPS khi hiện HUD tốc độ hoặc đang xem bản đồ. */
    private fun wantLocation() = Prefs.hudEnabled(context) || mapVisible

    fun updateLocationState() {
        if (wantLocation()) startLocation() else stopLocation()
    }

    private fun startLocation() {
        if (locActive) return
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) return
        val lm = context.getSystemService(LocationManager::class.java) ?: return
        locMgr = lm
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 1f, locListener, Looper.getMainLooper())
            lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2000L, 5f, locListener, Looper.getMainLooper())
            lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)?.let { pushLocation(it) }
            locActive = true
        } catch (_: Throwable) {
        }
    }

    private fun stopLocation() {
        try {
            locMgr?.removeUpdates(locListener)
        } catch (_: Throwable) {
        }
        locMgr = null
        locActive = false
    }

    private fun pushLocation(loc: Location) {
        if (loc.hasSpeed()) {
            lastSpeedKmh = loc.speed * 3.6f
            updateHud()
        }
        if (mapVisible) {
            val bearing = if (loc.hasBearing()) loc.bearing else -1f
            val speed = if (loc.hasSpeed()) loc.speed * 3.6f else -1f
            val acc = if (loc.hasAccuracy()) loc.accuracy else -1f
            mapWebView?.evaluateJavascript(
                "window.updatePosition&&updatePosition(${loc.latitude},${loc.longitude},$bearing,$speed,$acc);", null
            )
        }
    }

    // ================= CHIA 2–3 KHUNG =================

    private inner class Pane(val index: Int) {
        private val title = TextView(context).apply {
            textSize = 13f; setTextColor(Color.WHITE); setPadding(dp(8), dp(4), dp(8), dp(4)); maxLines = 1
        }
        private val holder = FrameLayout(context)
        val frame: LinearLayout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(3), dp(3), dp(3), dp(3))
            val bar = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundColor(0xFF263238.toInt())
                addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                addView(barBtn("🌐") { toWeb(Prefs.homeUrl(context)) })
                addView(barBtn("🎬") { requestVideoPane(index) })
                addView(barBtn("↻") { if (isVideo) vPlayer?.seekTo(0) else web?.reload() })
            }
            addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(holder, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }

        private var web: WebView? = null
        private var vPlayer: ExoPlayer? = null
        private var vSurface: SurfaceView? = null
        private var vControls: View? = null
        var isVideo = false
            private set

        private fun barBtn(label: String, onClick: () -> Unit) = TextView(context).apply {
            text = label; textSize = 18f; setTextColor(Color.WHITE)
            setPadding(dp(12), dp(4), dp(12), dp(4)); isClickable = true
            setOnClickListener { onClick() }
        }

        fun bind(spec: String) {
            if (spec == CarHub.VIDEO_SENTINEL) showVideo() else toWeb(spec)
        }

        private fun toWeb(url: String) {
            isVideo = false
            CarHub.setSplitUrl(index, url)
            vPlayer?.pause()
            vSurface?.visibility = View.GONE
            vControls?.visibility = View.GONE
            val wv = web ?: newWebView(false) { u -> if (u != null) CarHub.setSplitUrl(index, u) }.also {
                web = it
                holder.addView(it, 0, FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
                ))
            }
            wv.visibility = View.VISIBLE
            wv.onResume()
            title.text = "Khung ${index + 1}"
            if (wv.url != url) wv.loadUrl(url)
        }

        private fun showVideo() {
            val uri = CarHub.videoUri ?: Prefs.lastVideo(context)?.let { Uri.parse(it) }
            if (uri == null) {
                toast("Chưa có video – chọn video trên điện thoại")
                toWeb(Prefs.homeUrl(context)); return
            }
            isVideo = true
            CarHub.setSplitUrl(index, CarHub.VIDEO_SENTINEL)
            web?.let { it.evaluateJavascript(PAUSE_JS, null); it.onPause(); it.visibility = View.GONE }
            ensureVideoViews()
            vSurface?.visibility = View.VISIBLE
            vControls?.visibility = View.VISIBLE
            title.text = "Khung ${index + 1} • Video"
            val p = vPlayer ?: return
            p.setVideoSurfaceView(vSurface)
            p.setMediaItem(MediaItem.fromUri(uri))
            p.prepare()
            val active = CarHub.splitActive == index
            p.volume = if (active) 1f else 0f
            if (active && !CarHub.blocked) p.play()
        }

        private fun ensureVideoViews() {
            if (vPlayer != null) return
            val sv = SurfaceView(context)
            vSurface = sv
            holder.addView(sv, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER
            ))
            val bar = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
                setBackgroundColor(0x88000000.toInt())
            }
            bar.addView(vBtn("⏪") { vPlayer?.let { it.seekTo((it.currentPosition - 10_000).coerceAtLeast(0)) } })
            bar.addView(vBtn("⏯") { togglePlayPane() })
            bar.addView(vBtn("⏩") { vPlayer?.let { it.seekTo(it.currentPosition + 10_000) } })
            vControls = bar
            holder.addView(bar, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM
            ))
            val ep = ExoPlayer.Builder(context).build()
            ep.setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true
            )
            ep.repeatMode = Player.REPEAT_MODE_ONE
            vPlayer = ep
        }

        private fun vBtn(label: String, onClick: () -> Unit) = TextView(context).apply {
            text = label; textSize = 20f; setTextColor(Color.WHITE)
            setPadding(dp(18), dp(6), dp(18), dp(6)); isClickable = true
            setOnClickListener { onClick() }
        }

        fun setActive(active: Boolean) {
            frame.background = GradientDrawable().apply {
                setColor(Color.BLACK)
                setStroke(dp(3), if (active) 0xFF42A5F5.toInt() else Color.TRANSPARENT)
            }
            title.setTextColor(if (active) 0xFF90CAF9.toInt() else Color.WHITE)
        }

        fun setMuted(muted: Boolean) {
            if (isVideo) vPlayer?.volume = if (muted) 0f else 1f
            else web?.evaluateJavascript(
                "document.querySelectorAll('video,audio').forEach(function(m){m.muted=$muted;});", null
            )
        }

        fun togglePlayPane() {
            if (isVideo) {
                val p = vPlayer ?: return
                if (p.isPlaying) p.pause() else if (!CarHub.blocked) p.play()
            } else web?.evaluateJavascript(TOGGLE_JS, null)
        }

        fun canGoBack(): Boolean = !isVideo && web?.canGoBack() == true
        fun goBack() { web?.goBack() }

        fun pause() {
            vPlayer?.pause()
            web?.let { it.evaluateJavascript(PAUSE_JS, null); it.onPause() }
        }

        fun resume() { if (!isVideo) web?.onResume() }

        fun destroy() {
            vPlayer?.release(); vPlayer = null
            web?.let { it.stopLoading(); it.destroy() }; web = null
        }
    }

    fun showSplit() {
        player?.pause(); pauseWebMedia()
        val container = splitContainer ?: LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Color.BLACK)
        }.also { splitContainer = it }

        if (panes.size != CarHub.splitCount) {
            destroyPanes()
            container.removeAllViews()
            for (i in 0 until CarHub.splitCount) {
                val pane = Pane(i)
                panes.add(pane)
                container.addView(
                    pane.frame,
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                        .apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }
                )
            }
        }
        setContent(container)
        panes.forEachIndexed { i, pane -> pane.resume(); pane.bind(CarHub.splitUrls[i]) }
        setActivePane(CarHub.splitActive.coerceIn(0, panes.size - 1))
        if (CarHub.blocked) pausePanes()
    }

    fun loadIntoActive(url: String) {
        panes.getOrNull(CarHub.splitActive)?.bind(url)
    }

    private fun requestVideoPane(i: Int) {
        if (CarHub.videoUri == null && Prefs.lastVideo(context) == null) {
            toast("Chưa có video – chọn video trên điện thoại trước"); return
        }
        panes.forEachIndexed { idx, pane -> if (idx != i && pane.isVideo) pane.bind(Prefs.homeUrl(context)) }
        panes.getOrNull(i)?.bind(CarHub.VIDEO_SENTINEL)
        setActivePane(i)
    }

    private fun setActivePane(i: Int) {
        if (panes.isEmpty()) return
        val active = i.coerceIn(0, panes.size - 1)
        CarHub.setSplitActive(active)
        panes.forEachIndexed { idx, pane ->
            pane.setActive(idx == active)
            if (!CarHub.blocked) pane.setMuted(idx != active)
        }
    }

    private fun paneAt(x: Float, y: Float): Int {
        val loc = IntArray(2)
        panes.forEachIndexed { idx, pane ->
            pane.frame.getLocationInWindow(loc)
            if (x >= loc[0] && x <= loc[0] + pane.frame.width &&
                y >= loc[1] && y <= loc[1] + pane.frame.height
            ) return idx
        }
        return -1
    }

    private fun pausePanes() = panes.forEach { it.pause() }

    private fun destroyPanes() {
        panes.forEach { it.destroy() }
        panes.clear()
    }

    // ================= TRÌNH PHÁT VIDEO (TOÀN MÀN HÌNH) =================

    private fun ensureVideoViews(): FrameLayout = videoContainer ?: FrameLayout(context).also { box ->
        box.setBackgroundColor(Color.BLACK)
        val sv = SurfaceView(context)
        box.addView(sv, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER
        ))
        videoSurface = sv

        val bar = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setBackgroundColor(0x88000000.toInt())
            setPadding(0, dp(6), 0, dp(6) + insetBottom)
        }
        bar.addView(ctrl("⏪ 10s") { player?.let { it.seekTo((it.currentPosition - 10_000).coerceAtLeast(0)) } })
        bar.addView(ctrl("⏯") { togglePlay() })
        bar.addView(ctrl("10s ⏩") { player?.let { it.seekTo(it.currentPosition + 10_000) } })
        bar.addView(ctrl("✕") { CarHub.openHome() })
        videoBar = bar
        box.addView(bar, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM
        ))
        videoContainer = box
    }

    private fun ctrl(label: String, onClick: () -> Unit) = TextView(context).apply {
        text = label; textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(dp(24), dp(8), dp(24), dp(8)); isClickable = true
        setOnClickListener { onClick() }
    }

    fun playVideo(uri: Uri, startMs: Long) {
        pauseWebMedia()
        val box = ensureVideoViews()
        setContent(box)
        val p = player ?: ExoPlayer.Builder(context).build().also { ep ->
            ep.setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true
            )
            ep.addListener(object : Player.Listener {
                override fun onVideoSizeChanged(videoSize: VideoSize) = fitVideo(videoSize)
                override fun onPlayerError(error: PlaybackException) {
                    toast("Không phát được video: ${error.errorCodeName}")
                }
            })
            player = ep
        }
        p.setVideoSurfaceView(videoSurface)
        p.setMediaItem(MediaItem.fromUri(uri), startMs)
        p.prepare()
        if (!CarHub.blocked) p.play()
    }

    private fun fitVideo(size: VideoSize) {
        val sv = videoSurface ?: return
        val box = videoContainer ?: return
        if (size.width == 0 || size.height == 0 || box.width == 0 || box.height == 0) return
        val ratio = size.width * size.pixelWidthHeightRatio / size.height
        var w = box.width
        var h = (w / ratio).toInt()
        if (h > box.height) { h = box.height; w = (h * ratio).toInt() }
        sv.layoutParams = FrameLayout.LayoutParams(w, h, Gravity.CENTER)
    }

    fun togglePlay() {
        val p = player
        when (CarHub.mode) {
            CarHub.Mode.VIDEO -> if (p != null) {
                if (p.isPlaying) p.pause() else if (!CarHub.blocked) p.play()
            }
            CarHub.Mode.WEB -> {
                if (CarHub.blocked) return
                webView?.evaluateJavascript(TOGGLE_JS, null)
            }
            CarHub.Mode.SPLIT -> {
                if (CarHub.blocked) return
                panes.getOrNull(CarHub.splitActive)?.togglePlayPane()
            }
            else -> {}
        }
    }

    fun pauseAll() {
        player?.pause(); pauseWebMedia(); pausePanes()
    }

    // ================= CHIẾU MÀN HÌNH (TEXTUREVIEW) =================

    fun setMirrorMode(on: Boolean) {
        if (on) showMirror() else if (mirrorShowing) showForCurrentMode()
    }

    private fun showMirror() {
        val box = mirrorBox ?: FrameLayout(context).apply {
            setBackgroundColor(Color.BLACK)
            val tv = TextureView(context)
            mirrorTv = tv
            tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) = attachMirror()
                override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {
                    mirrorViewW = w; mirrorViewH = h; applyMirrorTransform()
                }
                override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                    MirrorController.detachSurface()
                    mirrorSurface?.release(); mirrorSurface = null
                    return true
                }
                override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
            }
            addView(tv, match())
        }.also { mirrorBox = it }
        setContent(box)
        val tv = mirrorTv
        if (tv != null && tv.isAvailable) attachMirror()
    }

    private fun attachMirror() {
        val tv = mirrorTv ?: return
        val st = tv.surfaceTexture ?: return
        val phone = MirrorController.phoneSize()
        if (phone == null) { toast("Không lấy được kích thước màn hình điện thoại"); return }
        mirrorPhoneW = phone.x; mirrorPhoneH = phone.y
        st.setDefaultBufferSize(phone.x, phone.y)
        val surf = Surface(st)
        mirrorSurface = surf
        MirrorController.attachSurface(surf, phone.x, phone.y, MirrorController.phoneDpi())
        mirrorViewW = tv.width; mirrorViewH = tv.height
        applyMirrorTransform()
    }

    /** Co giãn ảnh chiếu: "vừa khung" (giữ tỷ lệ, có viền) hoặc "lấp đầy" (cắt mép). */
    fun applyMirrorTransform() {
        val tv = mirrorTv ?: return
        val vw = tv.width; val vh = tv.height
        if (vw == 0 || vh == 0 || mirrorPhoneW == 0 || mirrorPhoneH == 0) return
        mirrorViewW = vw; mirrorViewH = vh
        val pw = mirrorPhoneW.toFloat(); val ph = mirrorPhoneH.toFloat()
        val fit = minOf(vw / pw, vh / ph)
        val fill = maxOf(vw / pw, vh / ph)
        val scale = if (Prefs.mirrorFill(context)) fill else fit
        val dispW = pw * scale; val dispH = ph * scale
        val m = Matrix()
        m.setScale(dispW / vw, dispH / vh, vw / 2f, vh / 2f)
        tv.setTransform(m)
        tv.invalidate()
    }

    private fun mapToPhone(cx: Float, cy: Float): Pair<Float, Float>? {
        val vw = mirrorViewW.toFloat(); val vh = mirrorViewH.toFloat()
        val pw = mirrorPhoneW.toFloat(); val ph = mirrorPhoneH.toFloat()
        if (vw <= 0 || vh <= 0 || pw <= 0 || ph <= 0) return null
        val fit = minOf(vw / pw, vh / ph)
        val fill = maxOf(vw / pw, vh / ph)
        val scale = if (Prefs.mirrorFill(context)) fill else fit
        val dispW = pw * scale; val dispH = ph * scale
        val offX = (vw - dispW) / 2f; val offY = (vh - dispH) / 2f
        val px = (cx - offX) / scale; val py = (cy - offY) / scale
        if (px < 0 || py < 0 || px > pw || py > ph) return null
        return px to py
    }

    // ================= ĐIỀU HƯỚNG / KHÓA / THÔNG BÁO =================

    fun handleBack(): Boolean {
        if (fullscreenView != null) { exitFullscreen(); return true }
        if (CarHub.mode == CarHub.Mode.SPLIT) {
            val pane = panes.getOrNull(CarHub.splitActive) ?: return false
            if (pane.canGoBack()) { pane.goBack(); return true }
            return false
        }
        val wv = webView
        if (CarHub.mode == CarHub.Mode.WEB && wv != null && wv.canGoBack()) { wv.goBack(); return true }
        return false
    }

    fun setBlocked(b: Boolean) {
        if (!::blockOverlay.isInitialized) return
        blockOverlay.visibility = if (b) View.VISIBLE else View.GONE
        if (b) pauseAll()
    }

    fun toast(msg: String) {
        if (!::toastView.isInitialized) return
        toastView.text = msg
        toastView.visibility = View.VISIBLE
        handler.removeCallbacks(hideToast)
        handler.postDelayed(hideToast, 3500)
    }

    private val hideToast = Runnable { toastView.visibility = View.GONE }

    // ================= CHỈ DẪN ĐIỀU HƯỚNG + HUD TỐC ĐỘ =================

    private fun buildNavOverlay() {
        navIcon = ImageView(context)
        navPrimary = TextView(context).apply {
            textSize = 20f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; maxLines = 2
        }
        navSecondary = TextView(context).apply {
            textSize = 13f; setTextColor(0xFFB0BEC5.toInt()); maxLines = 1
        }
        val textCol = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            addView(navPrimary); addView(navSecondary)
        }
        navBar = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            isClickable = false
            visibility = View.GONE
            setPadding(dp(12), dp(8), dp(14), dp(8))
            background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(0xF0101A26.toInt()) }
            addView(navIcon, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginEnd = dp(10) })
            addView(textCol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(navBar, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP
        ).apply { leftMargin = dp(10); rightMargin = dp(10); topMargin = dp(8) })
    }

    private fun buildSpeedChip() {
        speedValue = TextView(context).apply {
            textSize = 26f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        }
        val unit = TextView(context).apply {
            text = "km/h"; textSize = 11f; setTextColor(0xFFB0BEC5.toInt()); gravity = Gravity.CENTER
        }
        speedChip = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            isClickable = false
            visibility = View.GONE
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = GradientDrawable().apply { cornerRadius = dp(18).toFloat(); setColor(0xF0101A26.toInt()) }
            addView(speedValue); addView(unit)
        }
        root.addView(speedChip, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.START
        ).apply { leftMargin = dp(12); bottomMargin = dp(12) })
    }

    fun updateNavOverlay() {
        if (!::navBar.isInitialized) return
        val show = Prefs.navEnabled(context) && NavController.active
        navBar.visibility = if (show) View.VISIBLE else View.GONE
        if (!show) return
        navPrimary.text = NavController.primary.ifEmpty { NavController.secondary }
        val extra = if (NavController.primary.isEmpty()) "" else NavController.secondary
        val sec = listOf(extra, NavController.eta).filter { it.isNotEmpty() }.joinToString("  •  ")
        navSecondary.text = sec
        navSecondary.visibility = if (sec.isEmpty()) View.GONE else View.VISIBLE
        val d: Drawable? = NavController.icon
        if (d != null) {
            navIcon.setImageDrawable(d); navIcon.visibility = View.VISIBLE
        } else navIcon.visibility = View.GONE
    }

    fun updateHud() {
        if (!::speedChip.isInitialized) return
        val show = Prefs.hudEnabled(context) && lastSpeedKmh >= 0
        speedChip.visibility = if (show) View.VISIBLE else View.GONE
        if (show) speedValue.text = Math.round(lastSpeedKmh).toString()
    }

    // ================= MÔ PHỎNG CẢM ỨNG =================

    fun injectTap(x: Float, y: Float) {
        if (mirrorShowing) {
            mapToPhone(x, y)?.let { MirrorController.tap(it.first, it.second) }
            return
        }
        endDrag.run()
        if (CarHub.mode == CarHub.Mode.SPLIT) {
            val idx = paneAt(x, y)
            if (idx >= 0 && idx != CarHub.splitActive) setActivePane(idx)
        }
        val down = SystemClock.uptimeMillis()
        dispatch(MotionEvent.ACTION_DOWN, x, y, down)
        handler.postDelayed({ dispatch(MotionEvent.ACTION_UP, x, y, down) }, 60)
    }

    fun injectScroll(distanceX: Float, distanceY: Float) {
        if (mirrorShowing) {
            if (!mScrollActive) {
                mScrollActive = true
                mStartX = mirrorViewW / 2f; mStartY = mirrorViewH / 2f
                mCurX = mStartX; mCurY = mStartY
            }
            mCurX = (mCurX - distanceX).coerceIn(0f, mirrorViewW.toFloat())
            mCurY = (mCurY - distanceY).coerceIn(0f, mirrorViewH.toFloat())
            handler.removeCallbacks(endMirrorScroll)
            handler.postDelayed(endMirrorScroll, 150)
            return
        }
        val decor = window?.decorView ?: return
        if (dragDownTime == 0L) {
            dragDownTime = SystemClock.uptimeMillis()
            val anchor = scrollAnchor(decor)
            dragX = anchor.first; dragY = anchor.second
            dispatch(MotionEvent.ACTION_DOWN, dragX, dragY, dragDownTime)
        }
        dragX = (dragX - distanceX).coerceIn(1f, decor.width - 1f)
        dragY = (dragY - distanceY).coerceIn(1f, decor.height - 1f)
        dispatch(MotionEvent.ACTION_MOVE, dragX, dragY, dragDownTime)
        handler.removeCallbacks(endDrag)
        handler.postDelayed(endDrag, 120)
    }

    private fun scrollAnchor(decor: View): Pair<Float, Float> {
        if (CarHub.mode == CarHub.Mode.SPLIT) {
            panes.getOrNull(CarHub.splitActive)?.let { pane ->
                val loc = IntArray(2)
                pane.frame.getLocationInWindow(loc)
                return (loc[0] + pane.frame.width / 2f) to (loc[1] + pane.frame.height / 2f)
            }
        }
        return decor.width / 2f to decor.height / 2f
    }

    private fun dispatch(action: Int, x: Float, y: Float, downTime: Long) {
        val decor = window?.decorView ?: return
        val ev = MotionEvent.obtain(downTime, SystemClock.uptimeMillis(), action, x, y, 0)
        ev.source = InputDevice.SOURCE_TOUCHSCREEN
        decor.dispatchTouchEvent(ev)
        ev.recycle()
    }

    companion object {
        private const val TOGGLE_JS =
            "(function(){var v=document.querySelector('video');if(v){if(v.paused)v.play();else v.pause();}})();"
        private const val PAUSE_JS =
            "document.querySelectorAll('video,audio').forEach(function(m){m.pause();});"
    }
}
