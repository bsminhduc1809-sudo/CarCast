package com.duc.carcast.car

import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Surface
import androidx.car.app.AppManager
import androidx.car.app.CarContext
import androidx.car.app.SurfaceCallback
import androidx.car.app.SurfaceContainer
import com.duc.carcast.CarHub
import com.duc.carcast.mirror.MirrorController

/**
 * Nhận "bề mặt vẽ" (Surface) của màn hình xe từ Android Auto, tạo một
 * VirtualDisplay và hiển thị CarPresentation (toàn bộ giao diện của app, kể cả
 * khung chiếu màn hình). Mọi thao tác chạm/kéo được chuyển tiếp vào Presentation.
 */
class CarRenderer(private val carContext: CarContext) : SurfaceCallback {

    private val main = Handler(Looper.getMainLooper())

    private var surface: Surface? = null
    var width = 0
        private set
    var height = 0
        private set
    var dpi = 160
        private set

    private var virtualDisplay: VirtualDisplay? = null
    var presentation: CarPresentation? = null
        private set
    private var visibleArea: Rect? = null

    fun register() {
        carContext.getCarService(AppManager::class.java).setSurfaceCallback(this)
    }

    fun unregister() {
        try {
            carContext.getCarService(AppManager::class.java).setSurfaceCallback(null)
        } catch (_: Exception) {
        }
        releaseAll()
    }

    private fun onMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else main.post(block)
    }

    override fun onSurfaceAvailable(surfaceContainer: SurfaceContainer) = onMain {
        releaseAll()
        val s = surfaceContainer.surface ?: return@onMain
        surface = s
        width = surfaceContainer.width
        height = surfaceContainer.height
        dpi = surfaceContainer.dpi
        Log.d(TAG, "Surface ${width}x$height @ $dpi dpi")

        val dm = carContext.getSystemService(DisplayManager::class.java)
        val vd = dm.createVirtualDisplay(
            "CarCast", width, height, dpi, s,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY
        )
        virtualDisplay = vd
        try {
            val p = CarPresentation(carContext, vd.display)
            p.show()
            presentation = p
            visibleArea?.let { p.setInsets(it, width, height) }
        } catch (e: Exception) {
            Log.e(TAG, "Không hiển thị được presentation", e)
        }
        refreshMirror()
        CarHub.notifyChanged()
    }

    override fun onVisibleAreaChanged(visibleArea: Rect) = onMain {
        this.visibleArea = Rect(visibleArea)
        presentation?.setInsets(visibleArea, width, height)
    }

    override fun onStableAreaChanged(stableArea: Rect) {}

    override fun onSurfaceDestroyed(surfaceContainer: SurfaceContainer) = onMain {
        releaseAll()
        CarHub.notifyChanged()
    }

    /** Hiện khung chiếu nếu đang có phiên chiếu, đúng chế độ và không bị khóa tốc độ. */
    fun refreshMirror() {
        val want = MirrorController.isActive && CarHub.mode == CarHub.Mode.MIRROR && !CarHub.blocked
        presentation?.setMirrorMode(want)
    }

    private fun releaseAll() {
        presentation?.let {
            try {
                it.dismiss()
            } catch (_: Exception) {
            }
        }
        presentation = null
        virtualDisplay?.release()
        virtualDisplay = null
        surface = null
    }

    // ---------- Cảm ứng từ màn hình xe → Presentation ----------

    override fun onClick(x: Float, y: Float) = onMain {
        presentation?.injectTap(x, y)
    }

    override fun onScroll(distanceX: Float, distanceY: Float) = onMain {
        presentation?.injectScroll(distanceX, distanceY)
    }

    override fun onFling(velocityX: Float, velocityY: Float) {}

    override fun onScale(focusX: Float, focusY: Float, scaleFactor: Float) {}

    companion object {
        private const val TAG = "CarRenderer"
    }
}
