package com.duc.carcast.car

import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Surface
import androidx.car.app.AppManager
import androidx.car.app.CarContext
import androidx.car.app.SurfaceCallback
import androidx.car.app.SurfaceContainer
import com.duc.carcast.CarHub
import com.duc.carcast.mirror.MirrorController

/**
 * Nhận "bề mặt vẽ" (Surface) của màn hình xe từ Android Auto rồi:
 *  - tạo một VirtualDisplay riêng trên Surface đó và hiển thị CarPresentation
 *    (giao diện Android bình thường: WebView, trình phát video, launcher…);
 *  - hoặc chuyển Surface sang VirtualDisplay của MediaProjection để chiếu
 *    nguyên màn hình điện thoại.
 * Thao tác chạm/kéo trên màn hình xe được chuyển tiếp vào nội dung tương ứng.
 */
class CarRenderer(private val carContext: CarContext) : SurfaceCallback {

    private val main = Handler(Looper.getMainLooper())

    private var surface: Surface? = null
    var width = 0
        private set
    var height = 0
        private set
    var dpi = 160
        private set

    private var virtualDisplay: VirtualDisplay? = null
    var presentation: CarPresentation? = null
        private set
    private var visibleArea: Rect? = null
    private var mirrorShown = false

    // Gom các sự kiện kéo liên tiếp thành một cử chỉ vuốt khi đang chiếu màn hình
    private var mirrorDragStartX = 0f
    private var mirrorDragStartY = 0f
    private var mirrorDragX = 0f
    private var mirrorDragY = 0f
    private var mirrorDragging = false
    private val finishMirrorDrag = Runnable {
        if (mirrorDragging) {
            mirrorDragging = false
            MirrorController.swipe(mirrorDragStartX, mirrorDragStartY, mirrorDragX, mirrorDragY)
        }
    }

    fun register() {
        carContext.getCarService(AppManager::class.java).setSurfaceCallback(this)
    }

    fun unregister() {
        try {
            carContext.getCarService(AppManager::class.java).setSurfaceCallback(null)
        } catch (_: Exception) {
        }
        releaseAll()
    }

    private fun onMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else main.post(block)
    }

    override fun onSurfaceAvailable(surfaceContainer: SurfaceContainer) = onMain {
        releaseAll()
        val s = surfaceContainer.surface ?: return@onMain
        surface = s
        width = surfaceContainer.width
        height = surfaceContainer.height
        dpi = surfaceContainer.dpi
        Log.d(TAG, "Surface ${width}x$height @ $dpi dpi")

        val dm = carContext.getSystemService(DisplayManager::class.java)
        val vd = dm.createVirtualDisplay(
            "CarCast", width, height, dpi, s,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY
        )
        virtualDisplay = vd
        try {
            val p = CarPresentation(carContext, vd.display)
            p.show()
            presentation = p
            visibleArea?.let { p.setVisibleArea(it, width, height) }
        } catch (e: Exception) {
            Log.e(TAG, "Không hiển thị được presentation", e)
        }
        refreshMirror()
        CarHub.notifyChanged()
    }

    override fun onVisibleAreaChanged(visibleArea: Rect) = onMain {
        this.visibleArea = Rect(visibleArea)
        presentation?.setVisibleArea(visibleArea, width, height)
    }

    override fun onStableAreaChanged(stableArea: Rect) {}

    override fun onSurfaceDestroyed(surfaceContainer: SurfaceContainer) = onMain {
        releaseAll()
        CarHub.notifyChanged()
    }

    /**
     * Hiện màn hình chiếu nếu: đang có phiên chiếu, đang ở chế độ MIRROR và
     * không bị khóa do xe chạy. Ngược lại hiện presentation của ứng dụng.
     */
    fun refreshMirror() {
        val s = surface ?: return
        val want = MirrorController.isActive && CarHub.mode == CarHub.Mode.MIRROR && !CarHub.blocked
        if (want == mirrorShown) return
        if (want) {
            virtualDisplay?.surface = null
            if (MirrorController.attach(carContext, s, width, height, dpi)) {
                mirrorShown = true
                presentation?.pauseAll()
            } else {
                virtualDisplay?.surface = s
            }
        } else {
            MirrorController.detach()
            virtualDisplay?.surface = s
            mirrorShown = false
        }
    }

    private fun releaseAll() {
        if (mirrorShown) {
            MirrorController.detach()
            mirrorShown = false
        }
        presentation?.let {
            try {
                it.dismiss()
            } catch (_: Exception) {
            }
        }
        presentation = null
        virtualDisplay?.release()
        virtualDisplay = null
        surface = null
    }

    // ---------- Cảm ứng từ màn hình xe ----------

    override fun onClick(x: Float, y: Float) = onMain {
        if (mirrorShown) MirrorController.tap(x, y) else presentation?.injectTap(x, y)
    }

    override fun onScroll(distanceX: Float, distanceY: Float) = onMain {
        if (mirrorShown) {
            if (!mirrorDragging) {
                mirrorDragging = true
                mirrorDragStartX = width / 2f
                mirrorDragStartY = height / 2f
                mirrorDragX = mirrorDragStartX
                mirrorDragY = mirrorDragStartY
            }
            mirrorDragX = (mirrorDragX - distanceX).coerceIn(0f, width.toFloat())
            mirrorDragY = (mirrorDragY - distanceY).coerceIn(0f, height.toFloat())
            main.removeCallbacks(finishMirrorDrag)
            main.postDelayed(finishMirrorDrag, 150)
        } else {
            presentation?.injectScroll(distanceX, distanceY)
        }
    }

    override fun onFling(velocityX: Float, velocityY: Float) {}

    override fun onScale(focusX: Float, focusY: Float, scaleFactor: Float) {}

    companion object {
        private const val TAG = "CarRenderer"
    }
}
