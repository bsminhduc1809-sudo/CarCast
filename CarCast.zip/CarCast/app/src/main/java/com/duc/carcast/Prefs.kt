package com.duc.carcast

import android.content.Context
import android.content.SharedPreferences

/** Cài đặt lưu trên điện thoại. */
object Prefs {
    private const val NAME = "carcast_prefs"

    private fun sp(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun homeUrl(ctx: Context): String =
        sp(ctx).getString("home_url", "https://m.youtube.com") ?: "https://m.youtube.com"

    fun setHomeUrl(ctx: Context, v: String) = sp(ctx).edit().putString("home_url", v).apply()

    fun lastUrl(ctx: Context): String? = sp(ctx).getString("last_url", null)
    fun setLastUrl(ctx: Context, v: String?) = sp(ctx).edit().putString("last_url", v).apply()

    fun lastVideo(ctx: Context): String? = sp(ctx).getString("last_video", null)
    fun setLastVideo(ctx: Context, v: String?) = sp(ctx).edit().putString("last_video", v).apply()

    /** Khóa nội dung khi xe chạy — mặc định BẬT. */
    fun speedLock(ctx: Context): Boolean = sp(ctx).getBoolean("speed_lock", true)
    fun setSpeedLock(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("speed_lock", v).apply()

    /** Ngưỡng tốc độ (km/h) bắt đầu khóa. */
    fun speedLimit(ctx: Context): Int = sp(ctx).getInt("speed_limit", 5)
    fun setSpeedLimit(ctx: Context, v: Int) =
        sp(ctx).edit().putInt("speed_limit", v.coerceIn(1, 60)).apply()

    /** Giữ CarCast chạy khi điện thoại tắt màn hình — mặc định BẬT. */
    fun keepAwake(ctx: Context): Boolean = sp(ctx).getBoolean("keep_awake", true)
    fun setKeepAwake(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("keep_awake", v).apply()
}
