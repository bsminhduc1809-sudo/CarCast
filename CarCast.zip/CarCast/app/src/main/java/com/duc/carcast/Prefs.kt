package com.duc.carcast

import android.content.Context
import android.content.SharedPreferences

/** Cài đặt lưu trên điện thoại. */
object Prefs {
    private const val NAME = "carcast_prefs"

    private fun sp(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun homeUrl(ctx: Context): String =
        sp(ctx).getString("home_url", "https://m.youtube.com") ?: "https://m.youtube.com"

    fun setHomeUrl(ctx: Context, v: String) = sp(ctx).edit().putString("home_url", v).apply()

    fun lastUrl(ctx: Context): String? = sp(ctx).getString("last_url", null)
    fun setLastUrl(ctx: Context, v: String?) = sp(ctx).edit().putString("last_url", v).apply()

    fun lastVideo(ctx: Context): String? = sp(ctx).getString("last_video", null)
    fun setLastVideo(ctx: Context, v: String?) = sp(ctx).edit().putString("last_video", v).apply()

    /** Khóa nội dung khi xe chạy — mặc định BẬT. */
    fun speedLock(ctx: Context): Boolean = sp(ctx).getBoolean("speed_lock", true)
    fun setSpeedLock(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("speed_lock", v).apply()

    /** Ngưỡng tốc độ (km/h) bắt đầu khóa. */
    fun speedLimit(ctx: Context): Int = sp(ctx).getInt("speed_limit", 5)
    fun setSpeedLimit(ctx: Context, v: Int) =
        sp(ctx).edit().putInt("speed_limit", v.coerceIn(1, 60)).apply()

    /** Giữ CarCast chạy khi điện thoại tắt màn hình — mặc định BẬT. */
    fun keepAwake(ctx: Context): Boolean = sp(ctx).getBoolean("keep_awake", true)
    fun setKeepAwake(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("keep_awake", v).apply()

    /** Bộ khung yêu thích, lưu dạng JSON (xem PresetStore). */
    fun presetsJson(ctx: Context): String = sp(ctx).getString("split_presets", "[]") ?: "[]"
    fun setPresetsJson(ctx: Context, v: String) = sp(ctx).edit().putString("split_presets", v).apply()

    /** Chiếu màn hình lấp đầy màn ô tô (cắt bớt mép) thay vì giữ nguyên tỷ lệ điện thoại. */
    fun mirrorFill(ctx: Context): Boolean = sp(ctx).getBoolean("mirror_fill", false)
    fun setMirrorFill(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("mirror_fill", v).apply()

    /** Hiện thanh chỉ dẫn điều hướng (đọc từ thông báo Google Maps/VietMap). */
    fun navEnabled(ctx: Context): Boolean = sp(ctx).getBoolean("nav_enabled", true)
    fun setNavEnabled(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("nav_enabled", v).apply()

    /** Hiện HUD tốc độ (GPS). */
    fun hudEnabled(ctx: Context): Boolean = sp(ctx).getBoolean("hud_enabled", true)
    fun setHudEnabled(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("hud_enabled", v).apply()
}
