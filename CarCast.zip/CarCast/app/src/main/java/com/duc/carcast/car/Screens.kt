package com.duc.carcast.car

import androidx.activity.OnBackPressedCallback
import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.CarIcon
import androidx.car.app.model.ItemList
import androidx.car.app.model.ListTemplate
import androidx.car.app.model.Row
import androidx.car.app.model.SearchTemplate
import androidx.car.app.model.Template
import androidx.car.app.navigation.model.NavigationTemplate
import androidx.core.graphics.drawable.IconCompat
import com.duc.carcast.CarHub
import com.duc.carcast.R
import com.duc.carcast.mirror.MirrorController

private fun CarContext.icon(res: Int): CarIcon =
    CarIcon.Builder(IconCompat.createWithResource(this, res)).build()

/**
 * Màn hình gốc: NavigationTemplate cho phép ứng dụng tự vẽ toàn bộ màn hình xe
 * (nội dung do CarRenderer vẽ), cùng vài nút điều khiển của Android Auto.
 */
class HomeScreen(carContext: CarContext) : Screen(carContext) {

    init {
        carContext.onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = CarHub.back()
        })
    }

    override fun onGetTemplate(): Template {
        val actions = ActionStrip.Builder()
            .addAction(
                Action.Builder().setTitle("Menu")
                    .setOnClickListener { screenManager.push(MenuScreen(carContext)) }
                    .build()
            )
            .addAction(
                Action.Builder().setTitle("Tìm")
                    .setOnClickListener { screenManager.push(SearchScreen(carContext)) }
                    .build()
            )
            .addAction(
                Action.Builder().setIcon(carContext.icon(R.drawable.ic_back))
                    .setOnClickListener { CarHub.back() }
                    .build()
            )
            .build()

        // Nút PAN: bật chế độ kéo để cuộn trang web / vuốt khi chiếu màn hình
        val mapActions = ActionStrip.Builder()
            .addAction(Action.PAN)
            .addAction(
                Action.Builder().setIcon(carContext.icon(R.drawable.ic_play_pause))
                    .setOnClickListener { CarHub.togglePlay() }
                    .build()
            )
            .addAction(
                Action.Builder().setIcon(carContext.icon(R.drawable.ic_home))
                    .setOnClickListener { CarHub.openHome() }
                    .build()
            )
            .build()

        return NavigationTemplate.Builder()
            .setActionStrip(actions)
            .setMapActionStrip(mapActions)
            .setPanModeListener { }
            .build()
    }
}

/** Menu chọn nội dung. */
class MenuScreen(carContext: CarContext) : Screen(carContext) {

    override fun onGetTemplate(): Template {
        val list = ItemList.Builder()

        fun item(title: String, sub: String? = null, action: () -> Unit) {
            val row = Row.Builder().setTitle(title)
            if (sub != null) row.addText(sub)
            row.setOnClickListener {
                screenManager.pop()
                action()
            }
            list.addItem(row.build())
        }

        item("Màn hình chính", "Đồng hồ và lối tắt") { CarHub.openHome() }
        item("YouTube") { CarHub.openYouTube(carContext) }
        item("Trình duyệt web", "Dùng nút Tìm để nhập địa chỉ") {
            CarHub.openWeb(com.duc.carcast.Prefs.lastUrl(carContext) ?: "https://www.google.com")
        }
        item("Video", "Video đã chọn trên điện thoại") { CarHub.openVideo(carContext) }
        item("Chia 2 khung", "Hai trang web song song") { CarHub.openSplit(carContext, 2) }
        item("Chia 3 khung", "Ba trang web song song") { CarHub.openSplit(carContext, 3) }
        if (MirrorController.isActive) {
            item("Xem màn hình điện thoại", "Đang chiếu") { CarHub.requestMirror(carContext) }
            item("Dừng chiếu màn hình") { MirrorController.stop() }
        } else {
            item("Chiếu màn hình điện thoại", "Cần xác nhận trên điện thoại") {
                CarHub.requestMirror(carContext)
            }
        }

        return ListTemplate.Builder()
            .setSingleList(list.build())
            .setTitle("CarCast")
            .setHeaderAction(Action.BACK)
            .build()
    }
}

/** Bàn phím của Android Auto (chỉ dùng được khi xe đứng yên). */
class SearchScreen(carContext: CarContext) : Screen(carContext) {

    override fun onGetTemplate(): Template =
        SearchTemplate.Builder(object : SearchTemplate.SearchCallback {
            override fun onSearchTextChanged(searchText: String) {}

            override fun onSearchSubmitted(searchText: String) {
                screenManager.pop()
                CarHub.submitText(searchText)
            }
        })
            .setHeaderAction(Action.BACK)
            .setSearchHint("Tìm YouTube hoặc nhập địa chỉ web")
            .setShowKeyboardByDefault(true)
            .setItemList(ItemList.Builder().build())
            .build()
}
