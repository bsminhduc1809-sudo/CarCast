package com.duc.carcast.car

import android.content.Intent
import android.net.Uri
import androidx.activity.OnBackPressedCallback
import androidx.car.app.CarContext
import androidx.car.app.CarToast
import androidx.car.app.Screen
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.CarIcon
import androidx.car.app.model.ItemList
import androidx.car.app.model.ListTemplate
import androidx.car.app.model.Row
import androidx.car.app.model.SearchTemplate
import androidx.car.app.model.Template
import androidx.car.app.navigation.model.NavigationTemplate
import androidx.core.graphics.drawable.IconCompat
import com.duc.carcast.CarHub
import com.duc.carcast.Prefs
import com.duc.carcast.PresetStore
import com.duc.carcast.R
import com.duc.carcast.mirror.MirrorController
import java.net.URLEncoder

private fun CarContext.icon(res: Int): CarIcon =
    CarIcon.Builder(IconCompat.createWithResource(this, res)).build()

/**
 * Màn hình gốc: NavigationTemplate cho phép ứng dụng tự vẽ toàn bộ màn hình xe
 * (nội dung do CarRenderer vẽ), cùng vài nút điều khiển của Android Auto.
 */
class HomeScreen(carContext: CarContext) : Screen(carContext) {

    init {
        carContext.onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = CarHub.back()
        })
    }

    override fun onGetTemplate(): Template {
        val actions = ActionStrip.Builder()
            .addAction(
                Action.Builder().setTitle("Menu")
                    .setOnClickListener { screenManager.push(MenuScreen(carContext)) }
                    .build()
            )
            .addAction(
                Action.Builder().setTitle("Tìm")
                    .setOnClickListener { screenManager.push(SearchScreen(carContext)) }
                    .build()
            )
            .addAction(
                Action.Builder().setIcon(carContext.icon(R.drawable.ic_back))
                    .setOnClickListener { CarHub.back() }
                    .build()
            )
            .build()

        // Nút PAN: bật chế độ kéo để cuộn trang web / vuốt khi chiếu màn hình
        val mapActions = ActionStrip.Builder()
            .addAction(Action.PAN)
            .addAction(
                Action.Builder().setIcon(carContext.icon(R.drawable.ic_play_pause))
                    .setOnClickListener { CarHub.togglePlay() }
                    .build()
            )
            .addAction(
                Action.Builder().setIcon(carContext.icon(R.drawable.ic_home))
                    .setOnClickListener { CarHub.openHome() }
                    .build()
            )
            .build()

        return NavigationTemplate.Builder()
            .setActionStrip(actions)
            .setMapActionStrip(mapActions)
            .setPanModeListener { }
            .build()
    }
}

/** Menu chọn nội dung. */
class MenuScreen(carContext: CarContext) : Screen(carContext) {

    override fun onGetTemplate(): Template {
        val list = ItemList.Builder()

        fun item(title: String, sub: String? = null, action: () -> Unit) {
            val row = Row.Builder().setTitle(title)
            if (sub != null) row.addText(sub)
            row.setOnClickListener {
                screenManager.pop()
                action()
            }
            list.addItem(row.build())
        }

        item("Màn hình chính", "Đồng hồ và lối tắt") { CarHub.openHome() }
        item("YouTube") { CarHub.openYouTube(carContext) }
        item("Tìm trên YouTube", "Bàn phím trên xe") { screenManager.push(SearchScreen(carContext)) }
        item("Trình duyệt web", "Dùng nút Tìm để nhập địa chỉ") {
            CarHub.openWeb(Prefs.lastUrl(carContext) ?: "https://www.google.com")
        }
        item("Bản đồ", "Vị trí của bạn trên bản đồ") { CarHub.openMap(carContext) }
        item("Dẫn đường", "Mở Google Maps / VietMap") {
            screenManager.push(SearchScreen(carContext, navigate = true))
        }
        item("Video", "Video đã chọn trên điện thoại") { CarHub.openVideo(carContext) }
        item("Chia 2 khung", "Hai khung song song") { CarHub.openSplit(carContext, 2) }
        item("Chia 3 khung", "Ba khung song song") { CarHub.openSplit(carContext, 3) }

        val presets = PresetStore.list(carContext)
        if (presets.isNotEmpty()) {
            list.addItem(
                Row.Builder()
                    .setTitle("Bộ khung yêu thích")
                    .addText("${presets.size} bộ đã lưu")
                    .setBrowsable(true)
                    .setOnClickListener { screenManager.push(PresetsScreen(carContext)) }
                    .build()
            )
        }

        if (MirrorController.isActive) {
            item("Xem màn hình điện thoại", "Đang chiếu") { CarHub.requestMirror(carContext) }
            item("Dừng chiếu màn hình") { MirrorController.stop() }
        } else {
            item("Chiếu màn hình điện thoại", "Cần xác nhận trên điện thoại") {
                CarHub.requestMirror(carContext)
            }
        }

        return ListTemplate.Builder()
            .setSingleList(list.build())
            .setTitle("CarCast")
            .setHeaderAction(Action.BACK)
            .build()
    }
}

/** Danh sách bộ khung yêu thích đã lưu, mở nhanh bằng một chạm. */
class PresetsScreen(carContext: CarContext) : Screen(carContext) {

    override fun onGetTemplate(): Template {
        val presets = PresetStore.list(carContext)
        val list = ItemList.Builder()
        if (presets.isEmpty()) {
            list.setNoItemsMessage("Chưa có bộ nào. Lưu bộ khung trong ứng dụng CarCast trên điện thoại.")
        } else {
            presets.forEach { preset ->
                val videoCount = preset.specs.count { it == CarHub.VIDEO_SENTINEL }
                val sub = "${preset.count} khung" + if (videoCount > 0) " • có video" else ""
                list.addItem(
                    Row.Builder()
                        .setTitle(preset.name)
                        .addText(sub)
                        .setOnClickListener {
                            screenManager.pop()
                            CarHub.openSplitPreset(carContext, preset)
                        }
                        .build()
                )
            }
        }
        return ListTemplate.Builder()
            .setSingleList(list.build())
            .setTitle("Bộ khung yêu thích")
            .setHeaderAction(Action.BACK)
            .build()
    }
}

/**
 * Bàn phím của Android Auto (chỉ dùng được khi xe đứng yên).
 * [navigate] = true: giao điểm đến cho app dẫn đường gốc (Google Maps/VietMap).
 */
class SearchScreen(
    carContext: CarContext,
    private val navigate: Boolean = false,
) : Screen(carContext) {

    override fun onGetTemplate(): Template =
        SearchTemplate.Builder(object : SearchTemplate.SearchCallback {
            override fun onSearchTextChanged(searchText: String) {}

            override fun onSearchSubmitted(searchText: String) {
                screenManager.pop()
                if (navigate) startNavigation(searchText) else CarHub.submitText(searchText)
            }
        })
            .setHeaderAction(Action.BACK)
            .setSearchHint(if (navigate) "Nhập điểm đến" else "Tìm YouTube hoặc nhập địa chỉ web")
            .setShowKeyboardByDefault(true)
            .setItemList(ItemList.Builder().build())
            .build()

    private fun startNavigation(query: String) {
        val q = query.trim()
        if (q.isEmpty()) return
        try {
            val uri = Uri.parse("geo:0,0?q=" + URLEncoder.encode(q, "UTF-8"))
            carContext.startCarApp(Intent(CarContext.ACTION_NAVIGATE, uri))
        } catch (_: Exception) {
            CarToast.makeText(carContext, "Không mở được app dẫn đường", CarToast.LENGTH_LONG).show()
        }
    }
}
