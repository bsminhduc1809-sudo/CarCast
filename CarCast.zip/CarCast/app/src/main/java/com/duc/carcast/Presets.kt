package com.duc.carcast

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Một "bộ khung yêu thích": số khung (2–3) và nội dung từng khung.
 * Mỗi phần tử trong [specs] là một địa chỉ web, hoặc [CarHub.VIDEO_SENTINEL]
 * nếu khung đó phát video trong máy.
 */
data class SplitPreset(
    val name: String,
    val count: Int,
    val specs: List<String>,
)

/** Lưu danh sách bộ khung yêu thích vào SharedPreferences dưới dạng JSON. */
object PresetStore {

    fun list(ctx: Context): List<SplitPreset> {
        val out = ArrayList<SplitPreset>()
        try {
            val arr = JSONArray(Prefs.presetsJson(ctx))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val specsArr = o.getJSONArray("specs")
                val specs = ArrayList<String>()
                for (j in 0 until specsArr.length()) specs.add(specsArr.getString(j))
                out.add(SplitPreset(o.getString("name"), o.getInt("count"), specs))
            }
        } catch (_: Exception) {
        }
        return out
    }

    /** Thêm mới hoặc ghi đè bộ cùng tên. */
    fun save(ctx: Context, preset: SplitPreset) {
        val all = list(ctx).filter { it.name != preset.name } + preset
        write(ctx, all)
    }

    fun delete(ctx: Context, name: String) {
        write(ctx, list(ctx).filter { it.name != name })
    }

    private fun write(ctx: Context, presets: List<SplitPreset>) {
        val arr = JSONArray()
        presets.forEach { p ->
            val specs = JSONArray()
            p.specs.forEach { specs.put(it) }
            arr.put(
                JSONObject()
                    .put("name", p.name)
                    .put("count", p.count)
                    .put("specs", specs)
            )
        }
        Prefs.setPresetsJson(ctx, arr.toString())
    }
}
